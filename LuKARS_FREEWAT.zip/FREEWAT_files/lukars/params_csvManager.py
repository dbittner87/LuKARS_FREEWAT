# -*- coding: utf-8 -*-
# ===============================================================================
#
#
# Copyright (c) 2015 IST-SUPSI (www.supsi.ch/ist)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
#
# ===============================================================================

"""
params_csvManager.py - read/write/investigate CSV files consisting of LuKARS parameters
"""    

from PyQt4.QtCore import QObject, pyqtSignal
from PyQt4.QtGui import QTableWidgetItem, QFileDialog
import pandas as pd 
import csv	
from oat.plugin import databaseManager

#       - open csv finder
#       - load csv parameter data
#       - save results to csv-file

# created, but unused functions
#       - read parameters from QlineEdits
#       - load data from CSV file to QlineEdits
	
class Params(QObject):
    """
	This class contains all methods to load CSV parameters data
    """
	
    exception = pyqtSignal(Exception)
    popupMessage = pyqtSignal(str)

    def __init__(self, gui):
        """Inits the class
        """
        self.gui = gui
        self.tmp_file = None
        super(Params, self).__init__()
        self.db = databaseManager.DatabaseManager()
        
    def init_gui(self):

        self.gui.addCsvFile.clicked.connect(self.open_csv_finder)
#        self.gui.csvPreview.clicked.connect(self.load_preview)

#       - open csv finder
        
    def open_csv_finder(self):
        """
            Open a file finder
        """
        dialog = QFileDialog()
        filename = dialog.getOpenFileNameAndFilter(self.gui, self.gui.tr("Select input file "), "",
                                                   "CSV (*.csv);; plain (*.txt)")

        if filename[0] == '':
            return

        self.gui.filePath.setText(filename[0])
 
#funktioniert nicht:       
#        datatype = self.setFileType_CSV.text()
#        if self.selected == datatype:
#            # Create sensor and load data from CSV
#            if not self.load_csv_param_data():
#                return False
#        else:
#            self.popup_error_message(self.tr("Unknown method"))
#            return False
#        if self.luksens.data.empty:
#            self.popup_error_message(self.tr("No data Found"))
#            return

#       - load csv parameter data

    def load_csv_param_data(self, path, sep=','):
        """
            Load data from CSV file with specific configuration
        """
        
        frame = pd.read_csv(path, sep=sep)

        dic = {}
        
        for i in range(len(frame)):
            for col in frame.columns:
                ls = map(str, frame[col])
                dic[col] = ls
        
        return dic
    
#        return params			


#       - save results to csv-file
			
    def save_to_csv(self, filepath):
        """
        Write lukars data to csv file

        Args:
            filepath (str): file path to save
        """
		
        self.data.to_csv(filepath, sep=', ') #IOError: [Errno 13] Permission denied: !!

    def save_to_csv(self, filepath): #in Datei sensor.py
        """
        Write oat data to csv file

        Args:
            filepath (str): file path to save
        """

        if self.ts.empty:
            return

        self.ts.to_csv(filepath, columns=['data', 'quality', 'obs_index', 'use'])
		
		

			
            
            
# created, but unused functions     
        
#       - read parameters from QlineEdits            
            
    def read_params_from_line(self):
        """
            Read parameters from QlineEdits
        """
        nrHydrotopes = self.setNrHydrotopes.value()
        if nrHydrotopes == 1:  

            E_b_ini_1t = inputE_b_ini_1.text()
            k_b_1t = inputk_b_1.text()
            E_ini_11t = inputE_ini_11.text()
            l_hyd_11t = input_l_11.text()
            alpha_11t = inputalpha_11.text()
            k_e_11t = inputk_e_11.text()
            k_is_11t = inputk_is_11.text()
            k_sec_11t = inputk_sec_11.text()
            e_min_11t = inpute_min_11.text()
            e_max_11t = inpute_max_11.text()
            e_sec_11t = inpute_sec_11.text()

            E_b_ini_1 = float(E_b_ini_1t)
            k_b_1 = float(k_b_1t)
            E_ini_11 = float(E_ini_11t)
            l_hyd_11 = float(l_hyd_11t)
            alpha_11 = float(alpha_11t)
            k_e_11 = float(k_e_11t)
            k_is_11 = float(k_is_11t)
            k_sec_11 = float(k_sec_11t)
            e_min_11 = float(e_min_11t)
            e_max_11 = float(e_max_11t)
            e_sec_11 = float(e_sec_11t)

            if E_b_ini_1t == "" or k_b_1t == "" or E_ini_11t == "" or l_hyd_11t == "" or alpha_11t == "" or k_e_11t == "" or k_is_11t == "" or k_sec_11t == "" or e_min_11t == "" or e_max_11t == "" or e_sec_11t == "":
                e = QMessageBox.warning(self, self.tr("Warning"), self.tr('One or more parameters not assigned!'))
                print e

        if nrHydrotopes == 2:  
            
            E_b_ini_2t = inputE_b_ini_2.text()
            k_b_2t = inputk_b_2.text()
            
            E_ini_21t = inputE_ini_21.text()
            l_hyd_21t = input_l_21.text()
            alpha_21t = inputalpha_21.text()
            k_e_21t = inputk_e_21.text()
            k_is_21t = inputk_is_21.text()
            k_sec_21t = inputk_sec_21.text()
            e_min_21t = inpute_min_21.text()
            e_max_21t = inpute_max_21.text()
            e_sec_21t = inpute_sec_21.text()
            
            E_ini_22t = inputE_ini_22.text()
            l_hyd_22t = input_l_22.text()
            alpha_22t = inputalpha_22.text()
            k_e_22t = inputk_e_22.text()
            k_is_22t = inputk_is_22.text()
            k_sec_22t = inputk_sec_22.text()
            e_min_22t = inpute_min_22.text()
            e_max_22t = inpute_max_22.text()
            e_sec_22t = inpute_sec_22.text()

            E_b_ini_2 = float(E_b_ini_2t)
            k_b_2 = float(k_b_2t)
            
            E_ini_21 = float(E_ini_21t)
            l_hyd_21 = float(l_hyd_21t)
            alpha_21 = float(alpha_21t)
            k_e_21 = float(k_e_21t)
            k_is_21 = float(k_is_21t)
            k_sec_21 = float(k_sec_21t)
            e_min_21 = float(e_min_21t)
            e_max_21 = float(e_max_21t)
            e_sec_21 = float(e_sec_21t)

            E_ini_22 = float(E_ini_22t)
            l_hyd_22 = float(l_hyd_22t)
            alpha_22 = float(alpha_22t)
            k_e_22 = float(k_e_22t)
            k_is_22 = float(k_is_22t)
            k_sec_22 = float(k_sec_22t)
            e_min_22 = float(e_min_22t)
            e_max_22 = float(e_max_22t)
            e_sec_22 = float(e_sec_22t)
            
        if nrHydrotopes == 3:  
            
            E_b_ini_3t = inputE_b_ini_3.text()
            k_b_3t = inputk_b_3.text()
            
            E_ini_31t = inputE_ini_31.text()
            l_hyd_31t = input_l_31.text()
            alpha_31t = inputalpha_31.text()
            k_e_31t = inputk_e_31.text()
            k_is_31t = inputk_is_31.text()
            k_sec_31t = inputk_sec_31.text()
            e_min_31t = inpute_min_31.text()
            e_max_31t = inpute_max_31.text()
            e_sec_31t = inpute_sec_31.text()
            
            E_ini_32t = inputE_ini_32.text()
            l_hyd_32t = input_l_32.text()
            alpha_32t = inputalpha_32.text()
            k_e_32t = inputk_e_32.text()
            k_is_32t = inputk_is_32.text()
            k_sec_32t = inputk_sec_32.text()
            e_min_32t = inpute_min_32.text()
            e_max_32t = inpute_max_32.text()
            e_sec_32t = inpute_sec_32.text()
            
            E_ini_33t = inputE_ini_33.text()
            l_hyd_33t = input_l_33.text()
            alpha_33t = inputalpha_33.text()
            k_e_33t = inputk_e_33.text()
            k_is_33t = inputk_is_33.text()
            k_sec_33t = inputk_sec_33.text()
            e_min_33t = inpute_min_33.text()
            e_max_33t = inpute_max_33.text()
            e_sec_33t = inpute_sec_33.text()
            
            
            E_b_ini_3 = float(E_b_ini_3t)
            k_b_3 = float(k_b_3t)
            
            E_ini_31 = float(E_ini_31t)
            l_hyd_31 = float(l_hyd_31t)
            alpha_31 = float(alpha_31t)
            k_e_31 = float(k_e_31t)
            k_is_31 = float(k_is_31t)
            k_sec_31 = float(k_sec_31t)
            e_min_31 = float(e_min_31t)
            e_max_31 = float(e_max_31t)
            e_sec_31 = float(e_sec_31t)

            E_ini_32 = float(E_ini_32t)
            l_hyd_32 = float(l_hyd_32t)
            alpha_32 = float(alpha_32t)
            k_e_32 = float(k_e_32t)
            k_is_32 = float(k_is_32t)
            k_sec_32 = float(k_sec_32t)
            e_min_32 = float(e_min_32t)
            e_max_32 = float(e_max_32t)
            e_sec_32 = float(e_sec_32t)

            E_ini_33 = float(E_ini_33t)
            l_hyd_33 = float(l_hyd_33t)
            alpha_33 = float(alpha_33t)
            k_e_33 = float(k_e_33t)
            k_is_33 = float(k_is_33t)
            k_sec_33 = float(k_sec_33t)
            e_min_33 = float(e_min_33t)
            e_max_33 = float(e_max_33t)
            e_sec_33 = float(e_sec_33t)
            
        if nrHydrotopes == 4:  
            
            E_b_ini_4t = inputE_b_ini_4.text()
            k_b_4t = inputk_b_4.text()
            
            E_ini_41t = inputE_ini_41.text()
            l_hyd_41t = input_l_41.text()
            alpha_41t = inputalpha_41.text()
            k_e_41t = inputk_e_41.text()
            k_is_41t = inputk_is_41.text()
            k_sec_41t = inputk_sec_41.text()
            e_min_41t = inpute_min_41.text()
            e_max_41t = inpute_max_41.text()
            e_sec_41t = inpute_sec_41.text()
            
            E_ini_42t = inputE_ini_42.text()
            l_hyd_42t = input_l_42.text()
            alpha_42t = inputalpha_42.text()
            k_e_42t = inputk_e_42.text()
            k_is_42t = inputk_is_42.text()
            k_sec_42t = inputk_sec_42.text()
            e_min_42t = inpute_min_42.text()
            e_max_42t = inpute_max_42.text()
            e_sec_42t = inpute_sec_42.text()
            
            E_ini_43t = inputE_ini_43.text()
            l_hyd_43t = input_l_43.text()
            alpha_43t = inputalpha_43.text()
            k_e_43t = inputk_e_43.text()
            k_is_43t = inputk_is_43.text()
            k_sec_43t = inputk_sec_43.text()
            e_min_43t = inpute_min_43.text()
            e_max_43t = inpute_max_43.text()
            e_sec_43t = inpute_sec_43.text()
            
            E_ini_44t = inputE_ini_44.text()
            l_hyd_44t = input_l_44.text()
            alpha_44t = inputalpha_44.text()
            k_e_44t = inputk_e_44.text()
            k_is_44t = inputk_is_44.text()
            k_sec_44t = inputk_sec_44.text()
            e_min_44t = inpute_min_44.text()
            e_max_44t = inpute_max_44.text()
            e_sec_44t = inpute_sec_44.text()
             
            
            E_b_ini_4 = float(E_b_ini_4t)
            k_b_4 = float(k_b_4t)
            
            E_ini_41 = float(E_ini_41t)
            l_hyd_41 = float(l_hyd_41t)
            alpha_41 = float(alpha_41t)
            k_e_41 = float(k_e_41t)
            k_is_41 = float(k_is_41t)
            k_sec_41 = float(k_sec_41t)
            e_min_41 = float(e_min_41t)
            e_max_41 = float(e_max_41t)
            e_sec_41 = float(e_sec_41t)

            E_ini_42 = float(E_ini_42t)
            l_hyd_42 = float(l_hyd_42t)
            alpha_42 = float(alpha_42t)
            k_e_42 = float(k_e_42t)
            k_is_42 = float(k_is_42t)
            k_sec_42 = float(k_sec_42t)
            e_min_42 = float(e_min_42t)
            e_max_42 = float(e_max_42t)
            e_sec_42 = float(e_sec_42t)

            E_ini_43 = float(E_ini_43t)
            l_hyd_43 = float(l_hyd_43t)
            alpha_43 = float(alpha_43t)
            k_e_43 = float(k_e_43t)
            k_is_43 = float(k_is_43t)
            k_sec_43 = float(k_sec_43t)
            e_min_43 = float(e_min_43t)
            e_max_43 = float(e_max_43t)
            e_sec_43 = float(e_sec_43t)

            E_ini_44 = float(E_ini_44t)
            l_hyd_44 = float(l_hyd_44t)
            alpha_44 = float(alpha_44t)
            k_e_44 = float(k_e_44t)
            k_is_44 = float(k_is_44t)
            k_sec_44 = float(k_sec_44t)
            e_min_44 = float(e_min_44t)
            e_max_44 = float(e_max_44t)
            e_sec_44 = float(e_sec_44t)
                       
#       - load data from CSV file to QlineEdits                    

    def par_to_lines(self):
        """
            Load data from CSV file to QlineEdits
        """
        nrHydrotopes = self.setNrHydrotopes.value()
        if nrHydrotopes == 1:
            

#            E_b_ini_t1 = str(E_b_ini_array[1])
            E_b_ini_t1 = "a" #funktioniert auch nicht! Nichts in Box dargestellt Vielleicht Database-Speichern der Variablen?
            k_b_t1 = str(k_b_array[1])
            E_ini_t11 = str(E_ini_array[1])
            l_hyd_t11 = str(l_hyd_array[1])
            alpha_t11 = str(alpha_array[1])
            k_e_t11 = str(k_e_array[1])
            k_is_t11 = str(k_is_array[1])
            k_sec_t11 = str(k_sec_array[1])
            e_min_t11 = str(e_min_array[1])
            e_max_t11 = str(e_max_array[1])
            e_sec_t11 = str(e_sec_array[1])

            self.gui.inputE_b_ini_1.setText(E_b_ini_t1) #gui bringt auch nichts...
            self.gui.inputk_b_1.setText(k_b_t1)
            
            self.gui.inputE_ini_11.setText(E_ini_t11)
            self.gui.input_l_11.setText(l_hyd_t11)
            self.gui.inputalpha_11.setText(alpha_t11)
            self.gui.inputk_e_11.setText(k_e_t11)
            self.gui.inputk_is_11.setText(k_is_t11)
            self.gui.inputk_sec_11.setText(k_sec_t11)
            self.gui.inpute_min_11.setText(e_min_t11)
            self.gui.inpute_max_11.setText(e_max_t11)
            self.gui.inpute_sec_11.setText(e_sec_t11)

        if nrHydrotopes == 2:  
            
            E_b_ini_t2 = str(E_b_ini_array[1])
            k_b_t2 = str(k_b_array[1])
            E_ini_t21 = str(E_ini_array[1])
            l_hyd_t21 = str(l_hyd_array[1])
            alpha_t21 = str(alpha_array[1])
            k_e_t21 = str(k_e_array[1])
            k_is_t21 = str(k_is_array[1])
            k_sec_t21 = str(k_sec_array[1])
            e_min_t21 = str(e_min_array[1])
            e_max_t21 = str(e_max_array[1])
            e_sec_t21 = str(e_sec_array[1])
            
            E_ini_t22 = str(E_ini_array[2])
            l_hyd_t22 = str(l_hyd_array[2])
            alpha_t22 = str(alpha_array[2])
            k_e_t22 = str(k_e_array[2])
            k_is_t22 = str(k_is_array[2])
            k_sec_t22 = str(k_sec_array[2])
            e_min_t22 = str(e_min_array[2])
            e_max_t22 = str(e_max_array[2])
            e_sec_t22 = str(e_sec_array[2])
            
            
            self.inputE_b_ini_2.setText(E_b_ini_t2)
            self.inputk_b_2.setText(k_b_t2)
            
            self.inputE_ini_21.setText(E_ini_t21)
            self.input_l_21.setText(l_hyd_t21)
            self.inputalpha_21.setText(alpha_t21)
            self.inputk_e_21.setText(k_e_t21)
            self.inputk_is_21.setText(k_is_t21)
            self.inputk_sec_21.setText(k_sec_t21)
            self.inpute_min_21.setText(e_min_t21)
            self.inpute_max_21.setText(e_max_t21)
            self.inpute_sec_21.setText(e_sec_t21)
            
            self.inputE_ini_22.setText(E_ini_t22)
            self.input_l_22.setText(l_hyd_t22)
            self.inputalpha_22.setText(alpha_t22)
            self.inputk_e_22.setText(k_e_t22)
            self.inputk_is_22.setText(k_is_t22)
            self.inputk_sec_22.setText(k_sec_t22)
            self.inpute_min_22.setText(e_min_t22)
            self.inpute_max_22.setText(e_max_t22)
            self.inpute_sec_22.setText(e_sec_t22)
            
        if nrHydrotopes == 3:  
            
            E_b_ini_t3 = str(E_b_ini_array[1])
            k_b_t3 = str(k_b_array[1])
            E_ini_t31 = str(E_ini_array[1])
            l_hyd_t31 = str(l_hyd_array[1])
            alpha_t31 = str(alpha_array[1])
            k_e_t31 = str(k_e_array[1])
            k_is_t31 = str(k_is_array[1])
            k_sec_t31 = str(k_sec_array[1])
            e_min_t31 = str(e_min_array[1])
            e_max_t31 = str(e_max_array[1])
            e_sec_t31 = str(e_sec_array[1])
            
            E_ini_t32 = str(E_ini_array[2])
            l_hyd_t32 = str(l_hyd_array[2])
            alpha_t3 = str(alpha_array[2])
            k_e_t32 = str(k_e_array[2])
            k_is_t32 = str(k_is_array[2])
            k_sec_t32 = str(k_sec_array[2])
            e_min_t32 = str(e_min_array[2])
            e_max_t32 = str(e_max_array[2])
            e_sec_t32 = str(e_sec_array[2])
            
            E_ini_t33 = str(E_ini_array[3])
            l_hyd_t33 = str(l_hyd_array[3])
            alpha_t33 = str(alpha_array[3])
            k_e_t33 = str(k_e_array[3])
            k_is_t33 = str(k_is_array[3])
            k_sec_t33 = str(k_sec_array[3])
            e_min_t33 = str(e_min_array[3])
            e_max_t33 = str(e_max_array[3])
            e_sec_t33 = str(e_sec_array[3])
            
            self.inputE_b_ini_3.setText(E_b_ini_t3)
            self.inputk_b_3.setText(k_b_t3)
            
            self.inputE_ini_31.setText(E_ini_t31)
            self.input_l_31.setText(l_hyd_t31)
            self.inputalpha_31.setText(alpha_t31)
            self.inputk_e_31.setText(k_e_t31)
            self.inputk_is_31.setText(k_is_t31)
            self.inputk_sec_31.setText(k_sec_t31)
            self.inpute_min_31.setText(e_min_t31)
            self.inpute_max_31.setText(e_max_t31)
            self.inpute_sec_31.setText(e_sec_t31)
            
            self.inputE_ini_32.setText(E_ini_t32)
            self.input_l_32.setText(l_hyd_t32)
            self.inputalpha_32.setText(alpha_t32)
            self.inputk_e_32.setText(k_e_t32)
            self.inputk_is_32.setText(k_is_t32)
            self.inputk_sec_32.setText(k_sec_t32)
            self.inpute_min_32.setText(e_min_t32)
            self.inpute_max_32.setText(e_max_t32)
            self.inpute_sec_32.setText(e_sec_t32)
            
            self.inputE_ini_33.setText(E_ini_t33)
            self.input_l_33.setText(l_hyd_t33)
            self.inputalpha_33.setText(alpha_t33)
            self.inputk_e_33.setText(k_e_t33)
            self.inputk_is_33.setText(k_is_t33)
            self.inputk_sec_33.setText(k_sec_t33)
            self.inpute_min_33.setText(e_min_t33)
            self.inpute_max_33.setText(e_max_t33)
            self.inpute_sec_33.setText(e_sec_t33)
            
        if nrHydrotopes == 4:  
            
            E_b_ini_t4 = str(E_b_ini_array[1])
            k_b_t4 = str(k_b_array[1])
            E_ini_t41 = str(E_ini_array[1])
            l_hyd_t41 = str(l_hyd_array[1])
            alpha_t41 = str(alpha_array[1])
            k_e_t41 = str(k_e_array[1])
            k_is_t41 = str(k_is_array[1])
            k_sec_t41 = str(k_sec_array[1])
            e_min_t41 = str(e_min_array[1])
            e_max_t41 = str(e_max_array[1])
            e_sec_t41 = str(e_sec_array[1])
            
            E_ini_t42 = str(E_ini_array[2])
            l_hyd_t42 = str(l_hyd_array[2])
            alpha_t42 = str(alpha_array[2])
            k_e_t42 = str(k_e_array[2])
            k_is_t42 = str(k_is_array[2])
            k_sec_t42 = str(k_sec_array[2])
            e_min_t42 = str(e_min_array[2])
            e_max_t42 = str(e_max_array[2])
            e_sec_t42 = str(e_sec_array[2])
            
            E_ini_t43 = str(E_ini_array[3])
            l_hyd_t43 = str(l_hyd_array[3])
            alpha_t43 = str(alpha_array[3])
            k_e_t43 = str(k_e_array[3])
            k_is_t43 = str(k_is_array[3])
            k_sec_t43 = str(k_sec_array[3])
            e_min_t43 = str(e_min_array[3])
            e_max_t43 = str(e_max_array[3])
            e_sec_t43 = str(e_sec_array[3])
            
            E_ini_t44 = str(E_ini_array[4])
            l_hyd_t44 = str(l_hyd_array[4])
            alpha_t44 = str(alpha_array[4])
            k_e_t44 = str(k_e_array[4])
            k_is_t44 = str(k_is_array[4])
            k_sec_t44 = str(k_sec_array[4])
            e_min_t44 = str(e_min_array[4])
            e_max_t44 = str(e_max_array[4])
            e_sec_t44 = str(e_sec_array[4])
            
            self.inputE_b_ini_4.setText(E_b_ini_t4)
            self.inputk_b_4.setText(k_b_t4)
            
            self.inputE_ini_41.setText(E_ini_t41)
            self.input_l_41.setText(l_hyd_t41)
            self.inputalpha_41.setText(alpha_t41)
            self.inputk_e_41.setText(k_e_t41)
            self.inputk_is_41.setText(k_is_t41)
            self.inputk_sec_41.setText(k_sec_t41)
            self.inpute_min_41.setText(e_min_t41)
            self.inpute_max_41.setText(e_max_t41)
            self.inpute_sec_41.setText(e_sec_t41)
            
            self.inputE_ini_42.setText(E_ini_t42)
            self.input_l_42.setText(l_hyd_t42)
            self.inputalpha_42.setText(alpha_t42)
            self.inputk_e_42.setText(k_e_t42)
            self.inputk_is_42.setText(k_is_t42)
            self.inputk_sec_42.setText(k_sec_t42)
            self.inpute_min_42.setText(e_min_t42)
            self.inpute_max_42.setText(e_max_t42)
            self.inpute_sec_42.setText(e_sec_t42)
            
            self.inputE_ini_43.setText(E_ini_t43)
            self.input_l_43.setText(l_hyd_t43)
            self.inputalpha_43.setText(alpha_t43)
            self.inputk_e_43.setText(k_e_t43)
            self.inputk_is_43.setText(k_is_t43)
            self.inputk_sec_43.setText(k_sec_t43)
            self.inpute_min_43.setText(e_min_t43)
            self.inpute_max_43.setText(e_max_t43)
            self.inpute_sec_43.setText(e_sec_t43)
            
            self.inputE_ini_44.setText(E_ini_t44)
            self.input_l_44.setText(l_hyd_t44)
            self.inputalpha_44.setText(alpha_t44)
            self.inputk_e_44.setText(k_e_t44)
            self.inputk_is_44.setText(k_is_t44)
            self.inputk_sec_44.setText(k_sec_t44)
            self.inpute_min_44.setText(e_min_t44)
            self.inpute_max_44.setText(e_max_t44)
            self.inpute_sec_44.setText(e_sec_t44)


    def plot(self, data=True, quality=False, kind='line', data_color='b', axis=None, qaxis=None):
        """ plot function

        Args:
            data (bool): the sqlite file (including path)
            quality (bool): the sensor name to be used
            kind (str): kind of plot
            axis (): axis for data
            qaxis (): axis for quality plot

        """
        if not qaxis:
            qaxis = axis
        if data is True and quality is False:
            return self.ts['data'].plot(kind=kind, style=data_color, ax=axis)
        elif data is True and quality is True:
            self.ts['data'].plot(kind=kind, style=data_color, ax=axis)
            return self.ts['quality'].plot(kind=kind, style='r', ax=qaxis)
        elif data is False and quality is True:
            return self.ts['quality'].plot(kind=kind, style='r', ax=qaxis)
        else:
            raise Exception("data and quality cannot be both False")
 
#       - load data from CSV file to QlineEdits           
            
    def __load_param_data(self): #,params
        """
            Load data from csv file, read params from gui
        """
        # read path of selecte .csv file
        path = self.gui.filePath.text()

        if path == "":
			self.gui.popup_error_message(self.gui.tr("Please select a valid csv file"))
			return None

        if self.radioButton_Semicolon.isChecked() == True:
            separator = ';'
        elif self.radioButton_Tab.isChecked() == True:
            separator = "\t*"
        elif self.radioButton_Space.isChecked() == True:
            separator = "\s*"
        elif self.radioButton_Comma.isChecked() == True:
            separator = ','

        # load data from CSV
        try:
            self.par_from_csv(path)
        except Exception as e:
            print e
            if str(e) == '1':
                self.gui.popup_error_message(self.gui.tr("An error occurred: \n Wrong separator"))
            else:
                self.gui.popup_error_message(self.gui.tr("An error occurred:\n {}").format(e))
            return None

        return params			

#       - load data from CSV file to QlineEdits
		
	def par_from_csv(self, path):
		"""
		Load data from a CSV file
		"""
        
        # getting lists
		with open(path, 'rb') as f:
			reader = csv.reader(f)
			params = list(reader)
            
		header_array = params[0]
		E_b_ini_array = params[1]
		k_b_array = params[2]
		E_ini_array = params[3]
		l_hyd_array = params[4]
		alpha_array = params[5]
		k_e_array = params[6]
		k_is_array = params[7]
		k_sec_array = params[8]
		e_min_array = params[9]
		e_max_array = params[10]
		e_sec_array = params[11]
        
        #save to Database:
#        try:
#            self.E_b_ini_array.save_to_sqlite(config.db_path)
#        except Exception as e:
#            self.gui.popup_error_message(self.gui.tr("An error occurred:\n {}").format(e))
#            print e      

#		percRechArea = params[RowRechArea]
        
		#getting a dataframe
#		data = pd.read_csv(path)
        
        try:
            self.par_to_lines()
        except Exception as e:
            print e
            self.gui.popup_error_message(self.gui.tr("An error occurred:\n {}").format(e))
#            return None