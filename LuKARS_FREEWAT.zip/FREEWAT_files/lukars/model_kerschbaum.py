# -*- coding: utf-8 -*-
"""
1.import data
2.define model period
3.define parameters per hydrotope
4.run model
5.Plot results
"""

import os
import numpy as np
import matplotlib.pyplot as plt

#Hereinladen der Funktionen aus Modulen
import base_functions as basefun

os.chdir('C:\Users\Ayla\Documents\Uni\Master_Umweltingenieurwesen\Study_Project\input_data')

######### 1.import data #########

#Spalten auswählbar machen-->GUI
precip      = np.loadtxt('kerschbaum_py.csv', skiprows = 1, usecols = 1, delimiter = ';')
Q_obs       = np.loadtxt('kerschbaum_py.csv', skiprows = 1, usecols = 2, delimiter = ';')
temp        = np.loadtxt('kerschbaum_py.csv', skiprows = 1, usecols = 3, delimiter = ';')

######### 2.define model period #########

#--> GUI

period      = basefun.model_period('01/01/2001', '31/12/2016', 'D') #gemessene Datenreihe ist deutlich länger


######### 3.define parameters per hydrotope #########

#--> GUI

melt        = basefun.t_index_model(temp, 4, 0.5) #t_index_model(temperature_ts, melt_factor, t_threshold)
et          = basefun.et_model(period, temp) #et_model(model_period, temperature_ts)
intercep    = basefun.interception_losses(period) #interception_losses(model_period)

#sink_n_source(precipitation_ts, et_model = None, snow_model = None, \
#                  interception_losses = None, interception_threshold = None, \
#                  temperature_ts = None, t_threshold = None)
sns_term    = basefun.sink_n_source(precip, et_model = et, snow_model = melt, \
                            interception_losses = intercep, interception_threshold = 5, \
                            temperature_ts = temp, t_threshold = 0.5)
							
#Für Hydrotop 1:
sns_term_Q  = basefun.sink_n_source(precip, et_model = et, snow_model = melt, temperature_ts = temp,\
                            t_threshold = 0.5)

input_param = np.loadtxt('kerschbaum_input.txt', skiprows = 0, usecols = 1, delimiter = ';') #Reihen auswählbar machen

###############################
######### 4.run model #########
###############################

#lukars(sink_n_source_hyd_1, sink_n_source_hyd_2, sink_n_source_hyd_3,\
#           sink_n_source_hyd_4, input_parameters, time_step = 1)
model_run   = basefun.lukars(sns_term_Q, sns_term, sns_term, sns_term, input_param) 

######### 5.Plot results #########

### plot observed and simulated discharge time series
#--> pyplot
plt.figure()
plt.plot(period[1827:2556], model_run[1827:2556], color = 'blue')
plt.plot(period[1827:2556], Q_obs[1827:2556], color = 'red')