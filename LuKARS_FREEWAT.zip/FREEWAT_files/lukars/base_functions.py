#defining functions that are used for running the model

'''
1. Set model period and time steps
2. Snow melt for Sink and Source term
3. Evapotranspiration for Sink and Source term
4. Interception losses for Sink and Source term
5. Computing Sink and Source term
6. Model
'''


###1

import pandas as pd
from numpy import arange

def model_period(start_date, end_date, time_steps): # calibration time
    
    date_range = pd.date_range(start = start_date, end = end_date, freq = time_steps)
    return date_range
    
###2
    
def t_index_model(temperature_ts, melt_factor, t_threshold): 

    temp = temperature_ts
    mf = melt_factor
    t = t_threshold
    m_rate = [0] * len(temp)

    for i in range(len(temp)):
        if(temp[i] <= t):
            m_rate[i] = 0
        else:
            m_rate[i] = mf * (temp[i] - t)
            
    return m_rate
       
###3
    
def et_model(model_period, temperature_ts):
    
   # temp = pd.Series(temperature_ts, index = model_period)
    temp = temperature_ts.groupby(pd.Grouper(freq = 'M')).mean()
    heat_index = (temp/5)**1.514
    heat_index = heat_index.fillna(0)
    heat_index = heat_index.groupby(pd.Grouper(freq = 'A')).sum()
    heat_index = heat_index.repeat(12)
    
    a = (0.000000675 * heat_index**3) - (0.000071 * heat_index**2) + (0.01792 * heat_index) + 0.49239 #a=r im paper
    pe = {}
    for i in range(len(temp)):
        if(temp[i] <= 0):
            pe[i] = 0 # no evapotransp below 0 degrees
        else:
            pe[i] = 16 * ((10 * temp[i]) / heat_index[i])**a[i]

    pe = pd.Series(pe)
    pe = pe.fillna(0)
    
    days = pd.Series(temp.index.daysinmonth)
    pe_daily = {}
    
    for i in range(len(temp)):
        pe_daily[i] = pe[i] / days[i]
    
  #   x = pd.Series(15)
  #  days = x.append(days)
    days = days.cumsum()
  #  days = days[0:192]
    x = pd.Series(pe_daily)
    x.index = days
  #  day_seq = pd.Series(range(1, 5845))
  #  x = pd.Series(x, index = day_seq)
    ls = list(arange(1, len(temperature_ts)+1))
    x = pd.Series(x, index=ls)
    x = x.fillna(method='bfill') # better interpolate than backwards fill?
    x = x.fillna(0)
    x = list(x)
    return x
    
###4
    
def interception_losses(model_period):
    
   # I_loss = pd.Series([0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12])
    I_loss = [0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12]
    daily_losses = pd.Series(index = model_period)
    monthly_losses = daily_losses.groupby(pd.Grouper(freq = 'M')).mean()
    I_loss = I_loss * len(daily_losses.groupby(pd.Grouper(freq='A')).mean())
    # monthly_losses = pd.Series(pd.np.tile(I_loss, int(round(len(model_period)/365))), index = monthly_losses.index)
    for i in range(len(monthly_losses)):
        monthly_losses[i] = I_loss[i]
    days = pd.Series(monthly_losses.index.daysinmonth)
   # x = pd.Series(0.11)
   # monthly_losses = monthly_losses.append(x)
   # x = pd.Series(1)
   # days = x.append(days)
    days = days.cumsum()
    day_seq = pd.Series(range(1, len(model_period) + 2))
    monthly_losses.index = days
    x = pd.Series(monthly_losses, index = day_seq)
    x = x.interpolate()
    daily_losses = list(x[0:len(model_period)])
    
    return daily_losses
    
###5
    
def sink_n_source(precipitation_ts, et_model = None, snow_model = None, 
                  interception_losses = None, interception_threshold = None, 
                  temperature_ts = None, t_threshold = None):
        
    if et_model is None and snow_model is None and interception_losses is None:
        x = list(precipitation_ts)
    
    elif et_model is None and snow_model is None:
        precipitation = list(precipitation_ts)
        x = precipitation_ts * interception_losses
        
        if interception_threshold is None:
                    x = precipitation - x
        else:
                    x[x > interception_threshold] = interception_threshold
                    x = precipitation - x
                    
    elif snow_model is None and interception_losses is None:
        x = precipitation_ts - et_model
        x = list(x)
        
    elif et_model is None and interception_losses is None:
        temp = temperature_ts
        precipitation = precipitation_ts
        melt_x = [0] * len(precipitation_ts)
        x = [0] * len(precipitation_ts)
        x[0] = 0
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    melt_x[i] = 0
                    x[i+1]  = x[i] + precipitation[i+1]

                elif(x[i] >= snow_model[i]):
                    melt_x[i] = snow_model[i]
                    x[i+1]  = x[i] - snow_model[i]

                else:
                    melt_x[i] = x[i]
                    x[i+1]  = 0

        x[0] = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    x[i] = 0

                elif(melt_x[i] > 0):
                    x[i] = melt_x[i] + precipitation[i]

                else:
                    x[i] = precipitation[i]
                    
                    
    elif interception_losses is None:
        temp = temperature_ts
        precipitation = precipitation_ts
        melt_x = [0] * len(precipitation_ts)
        x = [0] * len(precipitation_ts)
        x[0] = 0
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    melt_x[i] = 0
                    x[i+1]  = x[i] + precipitation[i+1]

                elif(x[i] >= snow_model[i]):
                    melt_x[i] = snow_model[i]
                    x[i+1]  = x[i] - snow_model[i]

                else:
                    melt_x[i] = x[i]
                    x[i+1]  = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    x[i] = 0

                elif(melt_x[i] > 0):
                    x[i] = melt_x[i] + precipitation[i]

                else:
                    x[i] = precipitation[i]
                     
        x = [a - b for a, b in zip(x,et_model)]
    
    
    elif snow_model is None:
        x = precipitation_ts - et_model
        
        precipitation = precipitation_ts
        x = precipitation_ts * interception_losses
        
        if interception_threshold is None:
                    x = precipitation - x
        else:
                    x[x > interception_threshold] = interception_threshold
                    x = precipitation - x
        
                            
    elif et_model is None:
        temp = temperature_ts
        precipitation = list(precipitation_ts)
        x = precipitation_ts * interception_losses
        
        if interception_threshold is None:
                    x = precipitation - x
        else:
                    x[x > interception_threshold] = interception_threshold
                    x = precipitation - x
                    
        precipitation = list(x)        
        melt_x = [0] * len(precipitation_ts)
        x = [0] * len(precipitation_ts)
        x[0] = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    melt_x[i] = 0
                    x[i+1]  = x[i] + precipitation[i+1]

                elif(x[i] >= snow_model[i]):
                    melt_x[i] = snow_model[i]
                    x[i+1]  = x[i] - snow_model[i]

                else:
                    melt_x[i] = x[i]
                    x[i+1]  = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    x[i] = 0

                elif(melt_x[i] > 0):
                    x[i] = melt_x[i] + precipitation[i]

                else:
                    x[i] = precipitation[i]
                    
                    
    else:
        temp = temperature_ts
        precipitation = list(precipitation_ts)
        x = precipitation_ts * interception_losses
        
        if interception_threshold is None:
                    x = precipitation - x
        else:
                    x[x > interception_threshold] = interception_threshold
                    x = precipitation - x
                    
        precipitation = list(x)        
        melt_x = [0] * len(precipitation_ts)
        x = [0] * len(precipitation_ts)
        x[0] = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    melt_x[i] = 0
                    x[i+1]  = x[i] + precipitation[i+1]

                elif(x[i] >= snow_model[i]):
                    melt_x[i] = snow_model[i]
                    x[i+1]  = x[i] - snow_model[i]

                else:
                    melt_x[i] = x[i]
                    x[i+1]  = 0
        
        for i in range(len(precipitation_ts)-1):
                if(temp[i] < t_threshold):
                    x[i] = 0

                elif(melt_x[i] > 0):
                    x[i] = melt_x[i] + precipitation[i]

                else:
                    x[i] = precipitation[i]
        
        x = [a - b for a, b in zip(x,et_model)]
        
    return x
    
###6
    
def lukars(input_parameters, nrHyd, sink_n_source_hyd_1, sink_n_source_hyd_2 = None, sink_n_source_hyd_3 = None,\
           sink_n_source_hyd_4 = None, time_step = 1):
        

    if nrHyd in arange(1, 5):
        sns1        = list(sink_n_source_hyd_1)
    if nrHyd in arange(2, 5):
        sns2        = list(sink_n_source_hyd_2)
    if nrHyd in arange(3, 5):
        sns3        = list(sink_n_source_hyd_3)
    if nrHyd == 4:
        sns4        = list(sink_n_source_hyd_4)
    
    if nrHyd in arange(1, 5):
        a_hyd1      = input_parameters[0] * input_parameters[3]
    if nrHyd in arange(2, 5):
        a_hyd2      = input_parameters[0] * input_parameters[13]
    if nrHyd in arange(3, 5):
        a_hyd3      = input_parameters[0] * input_parameters[23]
    if nrHyd == 4:
        a_hyd4      = input_parameters[0] * input_parameters[33]
    
    Q_tot       = [0] * (len(sns1) + 1)
    Q_tot[0]    = 1
    Q_is        = [0] * (len(sns1) + 1)
    Q_is[0]     = 1
    Q_b         = [0] * (len(sns1) + 1)
    Q_b[0]      = 1
    Q_e         = [0] * (len(sns1) + 1)
    Q_e[0]      = 1
    Q_sec       = [0] * (len(sns1) + 1)
    Q_sec[0]    = 1
    
    # Linear storage
    E_b         = [0] * (len(sns1) + 1)
    E_b[0]      = input_parameters[1]
    k_b         = input_parameters[2]       
    
    if nrHyd in arange(1, 5):
        ### Hydrotope 1 #####
        # Non-Linear storage
        l_hyd_1     = input_parameters[4]
        k_e_1       = input_parameters[5] / l_hyd_1  
        E_1         = [0] * (len(sns1) + 1)
        E_1[0]      = input_parameters[6]    
        e_min_1     = input_parameters[7]    
        e_max_1     = input_parameters[8]    
        alpha_1     = input_parameters[9]
        Q_e_1       = [0] * (len(sns1) + 1)
        Q_e_1[0]    = 1

        # to Baseflow storage
        k_is_1      = input_parameters[10]   
        Q_is_1      = [0] * (len(sns1) + 1)
        Q_is[0]     = 1

        # secondary springs
        k_sec_1     = input_parameters[11]
        e_sec_1     = input_parameters[12]       
        Q_sec_1     = [0] * (len(sns1) + 1)
        Q_sec_1[0]  = 1

    if nrHyd in arange(2, 5):
        ### Hydrotope 2 #####
        l_hyd_2     = input_parameters[14]
        k_e_2       = input_parameters[15] / l_hyd_2   
        E_2         = [0] * (len(sns1) + 1)
        E_2[0]      = input_parameters[16]
        e_min_2     = input_parameters[17]
        e_max_2     = input_parameters[18]
        alpha_2     = input_parameters[19]
        Q_e_2       = [0] * (len(sns1) + 1)
        Q_e_2[0]    = 1

        # to Baseflow storage
        k_is_2      = input_parameters[20]
        Q_is_2      = [0] * (len(sns1) + 1)
        Q_is_2[0]   = 1

        # secondary springs
        k_sec_2     = input_parameters[21]
        e_sec_2     = input_parameters[22]
        Q_sec_2     = [0] * (len(sns1) + 1)
        Q_sec_2[0]  = 1

    if nrHyd in arange(3, 5):
        ### Hydrotope 3 ##### 
        l_hyd_3     = input_parameters[24]
        k_e_3       = input_parameters[25] / l_hyd_3   
        E_3         = [0] * (len(sns1) + 1)
        E_3[0]      = input_parameters[26]
        e_min_3     = input_parameters[27]    
        e_max_3     = input_parameters[28]    
        alpha_3     = input_parameters[29]
        Q_e_3       = [0] * (len(sns1) + 1)
        Q_e_3[0]    = 1

        # to Baseflow storage
        k_is_3      = input_parameters[30]
        Q_is_3      = [0] * (len(sns1) + 1)
        Q_is_3[0]   = 1

        # secondary springs
        k_sec_3     = input_parameters[31]
        e_sec_3     = input_parameters[32]
        Q_sec_3     = [0] * (len(sns1) + 1)
        Q_sec_3[0]  = 1

    if nrHyd == 4:
        ### Hydrotope 4 #####
        l_hyd_4     = input_parameters[34]
        k_e_4       = input_parameters[35] / l_hyd_4   
        E_4         = [0] * (len(sns1) + 1)
        E_4[0]      = input_parameters[36]
        e_min_4     = input_parameters[37]
        e_max_4     = input_parameters[38]
        alpha_4     = input_parameters[39]
        Q_e_4       = [0] * (len(sns1) + 1)
        Q_e_4[0]    = 1

        # to Baseflow storage
        k_is_4      = input_parameters[40]    
        Q_is_4      = [0] * (len(sns1) + 1)
        Q_is_4[0]   = 1

        # secondary springs
        k_sec_4     = input_parameters[41]
        e_sec_4     = input_parameters[42]
        Q_sec_4     = [0] * (len(sns1) + 1)
        Q_sec_4[0]  = 1

    #############################################
    ### Model ###################################
    #############################################
    
    for i in range(len(sns1)):
      
      #############################################
      ### Storages ################################
      #############################################
      
      if nrHyd in arange(1, 5):
          # non-linear, Hydrotop 1
          if((E_1[i] + (sns1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / a_hyd1)) * time_step) >= 0):
              E_1[i+1] = E_1[i] + (sns1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / a_hyd1)) * time_step
    
          else:
              E_1[i+1] = 0
              sns1[i]    = sns1[i] - (E_1[i] + (sns1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / 
                                                              a_hyd1)) * time_step)
      
      if nrHyd in arange(2, 5):
          # non-linear, Hydrotop 2
          if((E_2[i] + (sns2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / a_hyd2)) * time_step) >= 0):
              E_2[i+1] = E_2[i] + (sns2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / a_hyd2)) * time_step
    
          else:
              E_2[i+1] = 0
              sns2[i]    = sns2[i] - (E_2[i] + (sns2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / 
                                                              a_hyd2)) * time_step)
      
      if nrHyd in arange(3, 5):
          # non-linear, Hydrotop 3
          if((E_3[i] + (sns3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / a_hyd3)) * time_step) >= 0):
              E_3[i+1] = E_3[i] + (sns3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / a_hyd3)) * time_step
    
          else:
              E_3[i+1] = 0
              sns3[i]    = sns3[i] - (E_3[i] + (sns3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / 
                                                              a_hyd3)) * time_step)
      
      if nrHyd == 4:
          # non-linear, Hydrotop 4
          if((E_4[i] + (sns4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / a_hyd4)) * time_step) >= 0):   
              E_4[i+1] = E_4[i] + (sns4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / a_hyd4)) * time_step
      
          else:
              E_4[i+1] = 0
              sns4[i]    = sns4[i] - (E_4[i] + (sns4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / 
                                                              a_hyd4)) * time_step)
      
      # linear (baseflow storage)
      E_b[i+1] = E_b[i] + ((Q_is[i] - Q_b[i]) / input_parameters[0]) * time_step
      
      #############################################
      ### Flows ###################################
      #############################################
      
      # Q secondary springs
      if nrHyd in arange(1, 5):
          # Q secondary springs, Hydrotop 1
          if(E_1[i+1] >= e_sec_1):
              Q_sec_1[i+1] = k_sec_1 * a_hyd1 * (E_1[i+1] - e_sec_1)
      
          else:
              Q_sec_1[i+1] = 0
        
          Q_sec[i+1] = Q_sec_1[i+1]
      
      if nrHyd in arange(2, 5):
          # Q secondary springs, Hydrotop 2
          if(E_2[i+1] >= e_sec_2):
              Q_sec_2[i+1] = k_sec_2 * a_hyd2 * (E_2[i+1] - e_sec_2)
    
          else:
              Q_sec_2[i+1] = 0 
        
          Q_sec[i+1] = Q_sec_1[i+1] + Q_sec_2[i+1]
      
      if nrHyd in arange(3, 5):
          # Q secondary springs, Hydrotop 3
          if(E_3[i+1] >= e_sec_3):
              Q_sec_3[i+1] = k_sec_3 * a_hyd3 * (E_3[i+1] - e_sec_3)
      
          else:
              Q_sec_3[i+1] = 0
              
          Q_sec[i+1] = Q_sec_1[i+1] + Q_sec_2[i+1] + Q_sec_3[i+1]
      
      if nrHyd == 4:
          # Q secondary springs, Hydrotop 4
          if(E_4[i+1] >= e_sec_4):
              Q_sec_4[i+1] = k_sec_4 * a_hyd4 * (E_4[i+1] - e_sec_4)
      
          else:
              Q_sec_4[i+1] = 0 
      
          Q_sec[i+1] = Q_sec_1[i+1] + Q_sec_2[i+1] + Q_sec_3[i+1] + Q_sec_4[i+1]
          
      # Q inter-storage
      if nrHyd in arange(1, 5):
          # Q inter-storage, Hydrotop 1
          Q_is_1[i+1] = a_hyd1 * k_is_1 * E_1[i+1]
          
          # total
          Q_is[i+1]   = Q_is_1[i+1]
      
      if nrHyd in arange(2, 5):
          # Q inter-storage, Hydrotop 2
          Q_is_2[i+1] = a_hyd2 * k_is_2 * E_2[i+1]
          
          # total
          Q_is[i+1]   = Q_is_1[i+1] + Q_is_2[i+1]
      
      if nrHyd in arange(3, 5):
          # Q inter-storage, Hydrotop 3
          Q_is_3[i+1] = a_hyd3 * k_is_3 * E_3[i+1]
          
          # total
          Q_is[i+1]   = Q_is_1[i+1] + Q_is_2[i+1] + Q_is_3[i+1]
          
      if nrHyd == 4:      
          # Q inter-storage, Hydrotop 4
          Q_is_4[i+1] = a_hyd4 * k_is_4 * E_4[i+1]
          
          # total
          Q_is[i+1]   = Q_is_1[i+1] + Q_is_2[i+1] + Q_is_3[i+1] + Q_is_4[i+1]
      
      
      # Q baseflow
      Q_b[i+1] = input_parameters[0] * k_b * E_b[i+1]
      
      # Hysteresis function
      if nrHyd in arange(1, 5):
          # Hysteresis function, Hydrotop 1
          if(E_1[i+1] >= e_min_1 and Q_e_1[i] > 0):
              Q_e_1[i+1] = (((E_1[i+1] - e_min_1)/(e_max_1 - e_min_1))**alpha_1) * k_e_1 * a_hyd1
        
          elif(E_1[i+1] >= e_max_1 and Q_e_1[i] <= 0):
              Q_e_1[i+1] = (((E_1[i+1] - e_min_1)/(e_max_1 - e_min_1))**alpha_1) * k_e_1 * a_hyd1
        
          else:
              Q_e_1[i+1] = 0
              
          Q_e[i+1]   = Q_e_1[i+1]
      
      if nrHyd in arange(2, 5):
          # Hysteresis function, Hydrotop 2
          if(E_2[i+1] >= e_min_2 and Q_e_2[i] > 0):
              Q_e_2[i+1] = (((E_2[i+1] - e_min_2)/(e_max_2 - e_min_2))**alpha_2) * k_e_2 * a_hyd2
      
          elif(E_2[i+1] >= e_max_2 and Q_e_2[i] <= 0):
              Q_e_2[i+1] = (((E_2[i+1] - e_min_2)/(e_max_2 - e_min_2))**alpha_2) * k_e_2 * a_hyd2
      
          else:
              Q_e_2[i+1] = 0 
          
          Q_e[i+1]   = Q_e_1[i+1] + Q_e_2[i+1]
      
      if nrHyd in arange(3, 5):
          # Hysteresis function, Hydrotop 3
          if(E_3[i+1] >= e_min_3 and Q_e_3[i] > 0):
              Q_e_3[i+1] = (((E_3[i+1] - e_min_3)/(e_max_3 - e_min_3))**alpha_3) * k_e_3 * a_hyd3
      
          elif(E_3[i+1] >= e_max_3 and Q_e_3[i] <= 0): 
              Q_e_3[i+1] = (((E_3[i+1] - e_min_3)/(e_max_3 - e_min_3))**alpha_3) * k_e_3 * a_hyd3
      
          else:
              Q_e_3[i+1] = 0 
        
          Q_e[i+1]   = Q_e_1[i+1] + Q_e_2[i+1] + Q_e_3[i+1]
       
      if nrHyd == 4:
          # Hysteresis function, Hydrotop 4
          if(E_4[i+1] >= e_min_4 and Q_e_4[i] > 0):
              Q_e_4[i+1] = (((E_4[i+1] - e_min_4)/(e_max_4 - e_min_4))**alpha_4) * k_e_4 * a_hyd4
      
          elif(E_4[i+1] >= e_max_4 and Q_e_4[i] <= 0):
              Q_e_4[i+1] = (((E_4[i+1] - e_min_4)/(e_max_4 - e_min_4))**alpha_4) * k_e_4 * a_hyd4
      
          else:
              Q_e_4[i+1] = 0       
        
          Q_e[i+1]   = Q_e_1[i+1] + Q_e_2[i+1] + Q_e_3[i+1] + Q_e_4[i+1]
          
      
      Q_tot[i+1] = Q_e[i+1] + Q_b[i+1] #unit: m3/d
      
    Q_tot[:]     = [x / 86400 for x in Q_tot]
    Q_tot        = Q_tot[0:len(sns1)]
    return Q_tot