# -*- coding: utf-8 -*-
# ===============================================================================
#
#
# Copyright (c) 2015 IST-SUPSI (www.supsi.ch/ist)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
#
# ===============================================================================


from PyQt4.QtCore import QObject, pyqtSignal
from PyQt4.QtGui import QTableWidgetItem, QFileDialog
from PyQt4.QtGui import QDialog, QFileDialog, QInputDialog, QMessageBox, QPlainTextEdit
from oat.oatlib import sensor

import numpy as np
from ..freewat_utils import *
from ..sqlite_utils import getTableNamesList, uploadQgisVectorLayer
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
import os
from PyQt4 import QtGui, uic

import freewat.ftools_utils

from freewat.freewat_utils  import getVectorLayerByName, getVectorLayerNames, getFieldNames
from pyspatialite import dbapi2 as sqlite3
from qgis.PyQt.QtCore import QVariant

exception = pyqtSignal(Exception)
popupMessage = pyqtSignal(str)


#       -  calculate recharge area
#       -  calculate percentage of recharge area
#       -  add columns to attribute table
#       -  edit columns of attribute table
#       -  Save parameters from tab Define Parameters to shapefile
#       -  Load parameters from attribute table of shapefile to QLineEdits in tab Define Parameters

#created, but unused functions: 
#       -  read values from attribute table (+ set in boxes of parameters!)
#       -  load attribute table -> ftools_utils



# load shapefile

class ShpManager(QObject):
    
    """
        This class contains all method to manipulate csv data
    """

    def __init__(self, gui):
        self.gui = gui
        super(ShpManager, self).__init__()
    
#       -  calculate recharge area          
    
    def calculate_recharge_area(self, nrHydrotopes, vlayer1, vlayer2 = None, vlayer3 = None, 
                                vlayer4 = None):
        """
            Calculates the recharge area of the respective hydrotope
        """         
        rech_area = 0
        
        if nrHydrotopes == 1:
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
                
        elif nrHydrotopes == 2:
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
                
        elif nrHydrotopes == 3:
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer3.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
                
        elif nrHydrotopes == 4:
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer3.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer4.getFeatures():
                geom = f.geometry()
                rech_area = rech_area + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
        return rech_area

#       -  calculate percentage of recharge area            
    
    def calculate_perc_rech_area(self, nrHydrotopes, rech_area, vlayer1, vlayer2 = None, 
                                 vlayer3 = None, vlayer4 = None):
        """
            Calculates the percentage of the respective hydrotope's recharge area of all hydrotopes
        """             
        if nrHydrotopes == 1:
            
            return [1]
            
        elif nrHydrotopes == 2:
            
            rech_area_1 = 0
            rech_area_2 = 0
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area_1 = rech_area_1 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area_2 = rech_area_2 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            return  rech_area_1/rech_area, rech_area_2/rech_area
        
        elif nrHydrotopes == 3:
            
            rech_area_1 = 0
            rech_area_2 = 0
            rech_area_3 = 0
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area_1 = rech_area_1 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area_2 = rech_area_2 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer3.getFeatures():
                geom = f.geometry()
                rech_area_3 = rech_area_3 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            return  rech_area_1/rech_area, rech_area_2/rech_area, rech_area_3/rech_area
            
        elif nrHydrotopes == 4:
            
            rech_area_1 = 0
            rech_area_2 = 0
            rech_area_3 = 0
            rech_area_4 = 0
            
            for f in vlayer1.getFeatures():
                geom = f.geometry()
                rech_area_1 = rech_area_1 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer2.getFeatures():
                geom = f.geometry()
                rech_area_2 = rech_area_2 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer3.getFeatures():
                geom = f.geometry()
                rech_area_3 = rech_area_3 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            for f in vlayer4.getFeatures():
                geom = f.geometry()
                rech_area_4 = rech_area_4 + freewat.ftools_utils.getAreaAndPerimeter(geom)
            
            return  rech_area_1/rech_area, rech_area_2/rech_area, rech_area_3/rech_area, rech_area_4/rech_area
        else: 
            QMessageBox.warning(self, self.tr("Warning"), self.tr('Problem calculating percentage of recharge area.'))
    
            
#       -  add columns to attribute table
    
    def addColumn_double (layer, param):
        """
            Adds decimal columns to hydrotopes' shapefiles in order to write params to attribute table
        """  
        
        from PyQt4.QtCore import *
        layer = QgsMapLayerRegistry.instance().mapLayersByName('mittlerer_Ring')[0] #hier Abfrage Layername von Hydrotop-shapefile #geht auch ID
        iface.setActiveLayer(layer)
        #layer = qgis.utils.iface.activeLayer()
        layer.startEditing()
        layer.dataProvider().addAttributes( [ QgsField(param, QVariant.Double, "", 12,4) ] )
        layer.commitChanges()
    
#       -  edit columns of attribute table
    
    def editColumn_double (vlayer, param, value):
        """
            Edits the created columns with the attributes read from the QLineEdits
        """  
        with edit(layer):
            for feature in layer.getFeatures():
                feature.setAttribute(feature.fieldNameIndex(param), value) #als value definieren, was im CSV steht #https://developer.mozilla.org/de/docs/Web/API/Element/setAttribute
                layer.updateFeature(feature)


#       -  Save parameters from tab Define Parameters to shapefile
    
    def save_param_data(self):
        """
            Load data from CSV to hydrotopes shapefiles
        """
    
        try:
            self.gui.lukars = self.__save_data(self.gui.lukars) #what for oat/lukars?
    
            if not self.gui.lukars:
                return False
    
            return True
        except Exception as e:
            #print e
            widget = QWidget()
            QtGui.QMessageBox.warning(widget, 'Message',"Saving to hydrotope shapefiles did not work in __save_data.")
            return False

            
    def __save_data(self, vlayer1, vlayer2 = None, vlayer3 = None, vlayer4 = None): #,params
        """
            Load data from QlineEdits to shapefiles, read params from gui
        """
        
        try:
#            self.gui.lukars = self.get_params(self.gui.lukars) #wofür oat/lukars?
            self.get_params()
            
#            if not self.gui.lukars:
#                return False
    
#            return True
        except Exception as e:
            QMessageBox.warning(self, self.tr("Warning"), self.tr('Loading from QlineEdits to shapefiles did not work! (get_params)'))
            print e
#            return False
            
        try:
            if nrHydrotopes == 1:
                
                vlayer1 = hyd1
                vlayer1.startEditing(self) 
                try: 
                    with edit(vlayer1):
                        vlayer1.addAttribute(QgsField("E_b_ini", QVariant.Float))
                        vlayer1.updateFields()
                        for f in vlayer1.getFeatures():
                            f["E_b_ini"] = float(E_b_ini1)
                            vlayer1.updateFeature(f)                    
                    
                    
                    
                    #vlayer1.addAttribute(QgsField("E_b_ini", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("k_b", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("E_ini", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("l", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("alpha", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("k_e", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("k_is", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("k_sec", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("e_min", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("e_max", QVariant.Float))
                    #vlayer1.addAttribute(QgsField("e_sec", QVariant.Float))

                    #python cookbook modify features: 
                    #if caps & QgsVectorDataProvider.ChangeAttributeValues:
                    #    attrs = { 0 : "hello", 1 : 123 }
                    #    layer.dataProvider().changeAttributeValues({ fid : attrs })    
                    
                    #vlayer1.dataProvider().changeAttributeValues({ fid : attrs }) #fid?
                    
                    #shp.editColumn_double(hyd1, "E_b_ini", float(E_b_ini1))
                    #shp.editColumn_double(hyd1, "k_b", float(k_b1))
                    #shp.editColumn_double(hyd1, "E_ini", float(E_ini1))
                    #shp.editColumn_double(hyd1, "l", float(l1))       
                    #shp.editColumn_double(hyd1, "alpha", float(alpha1))   
                    #shp.editColumn_double(hyd1, "k_e", float(k_e1))
                    #shp.editColumn_double(hyd1, "k_is", float(k_is1))   
                    #shp.editColumn_double(hyd1, "k_sec", float(k_sec1))                
                    #shp.editColumn_double(hyd1, "e_min", float(e_min1))
                    #shp.editColumn_double(hyd1, "e_max", float(e_max1))
                    #shp.editColumn_double(hyd1, "e_sec", float(e_sec1))
                
                    #return True
                    #commitChanges(self)
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Adding attribute to shapefile failed (__save_data)'))
                    print e  
                    return False
                    rollBack(self)
                
                
                
            elif nrHydrotopes == 2:

                vlayer1 = hyd1
                vlayer2 = hyd2
                                
                shp.addColumn_double(hyd1, "E_b_ini")
                shp.addColumn_double(hyd1, "k_b")
                shp.addColumn_double(hyd1, "E_ini")
                shp.addColumn_double(hyd1, "l" )
                shp.addColumn_double(hyd1, "alpha")
                shp.addColumn_double(hyd1, "k_e") 
                shp.addColumn_double(hyd1, "k_is")
                shp.addColumn_double(hyd1, "k_sec")
                shp.addColumn_double(hyd1, "e_min")
                shp.addColumn_double(hyd1, "e_max")
                shp.addColumn_double(hyd1, "e_sec")    

                shp.addColumn_double(hyd2, "E_b_ini")
                shp.addColumn_double(hyd2, "k_b")
                shp.addColumn_double(hyd2, "E_ini")
                shp.addColumn_double(hyd2, "l" )
                shp.addColumn_double(hyd2, "alpha")
                shp.addColumn_double(hyd2, "k_e") 
                shp.addColumn_double(hyd2, "k_is")
                shp.addColumn_double(hyd2, "k_sec")
                shp.addColumn_double(hyd2, "e_min")
                shp.addColumn_double(hyd2, "e_max")
                shp.addColumn_double(hyd2, "e_sec")
                
                shp.editColumn_double(hyd1, "E_b_ini", float(E_b_ini1))
                shp.editColumn_double(hyd1, "k_b", float(k_b1))
                shp.editColumn_double(hyd1, "E_ini", float(E_ini1))
                shp.editColumn_double(hyd1, "l", float(l1))
                shp.editColumn_double(hyd1, "alpha", float(alpha1))
                shp.editColumn_double(hyd1, "k_e", float(k_e1))
                shp.editColumn_double(hyd1, "k_is", float(k_is1))
                shp.editColumn_double(hyd1, "k_sec", float(k_sec1))
                shp.editColumn_double(hyd1, "e_min", float(e_min1))
                shp.editColumn_double(hyd1, "e_max", float(e_max1))
                shp.editColumn_double(hyd1, "e_sec", float(e_sec1))
            
                shp.editColumn_double(hyd2, "E_b_ini", float(E_b_ini2))
                shp.editColumn_double(hyd2, "k_b", float(k_b2))
                shp.editColumn_double(hyd2, "E_ini", float(E_ini2))
                shp.editColumn_double(hyd2, "l", float(l2))
                shp.editColumn_double(hyd2, "alpha", float(alpha2))
                shp.editColumn_double(hyd2, "k_e", float(k_e2))
                shp.editColumn_double(hyd2, "k_is", float(k_is2))
                shp.editColumn_double(hyd2, "k_sec", float(k_sec2))
                shp.editColumn_double(hyd2, "e_min", float(e_min2))
                shp.editColumn_double(hyd2, "e_max", float(e_max2))
                shp.editColumn_double(hyd2, "e_sec", float(e_sec2))
                    
            elif nrHydrotopes == 3:
                
                vlayer1 = hyd1
                vlayer2 = hyd2
                vlayer3 = hyd3
                
                shp.addColumn_double(hyd1, "E_b_ini")
                shp.addColumn_double(hyd1, "k_b")
                shp.addColumn_double(hyd1, "E_ini")
                shp.addColumn_double(hyd1, "l" )
                shp.addColumn_double(hyd1, "alpha")
                shp.addColumn_double(hyd1, "k_e") 
                shp.addColumn_double(hyd1, "k_is")
                shp.addColumn_double(hyd1, "k_sec")
                shp.addColumn_double(hyd1, "e_min")
                shp.addColumn_double(hyd1, "e_max")
                shp.addColumn_double(hyd1, "e_sec")    

                shp.addColumn_double(hyd2, "E_b_ini")
                shp.addColumn_double(hyd2, "k_b")
                shp.addColumn_double(hyd2, "E_ini")
                shp.addColumn_double(hyd2, "l" )
                shp.addColumn_double(hyd2, "alpha")
                shp.addColumn_double(hyd2, "k_e") 
                shp.addColumn_double(hyd2, "k_is")
                shp.addColumn_double(hyd2, "k_sec")
                shp.addColumn_double(hyd2, "e_min")
                shp.addColumn_double(hyd2, "e_max")
                shp.addColumn_double(hyd2, "e_sec")

                shp.addColumn_double(hyd3, "E_b_ini")
                shp.addColumn_double(hyd3, "k_b")
                shp.addColumn_double(hyd3, "E_ini")
                shp.addColumn_double(hyd3, "l" )
                shp.addColumn_double(hyd3, "alpha")
                shp.addColumn_double(hyd3, "k_e") 
                shp.addColumn_double(hyd3, "k_is")
                shp.addColumn_double(hyd3, "k_sec")
                shp.addColumn_double(hyd3, "e_min")
                shp.addColumn_double(hyd3, "e_max")
                shp.addColumn_double(hyd3, "e_sec")
                
                shp.editColumn_double(hyd1, "E_b_ini", float(E_b_ini1))
                shp.editColumn_double(hyd1, "k_b", float(k_b1))
                shp.editColumn_double(hyd1, "E_ini", float(E_ini1))
                shp.editColumn_double(hyd1, "l", float(l1))
                shp.editColumn_double(hyd1, "alpha", float(alpha1))
                shp.editColumn_double(hyd1, "k_e", float(k_e1))
                shp.editColumn_double(hyd1, "k_is", float(k_is1))
                shp.editColumn_double(hyd1, "k_sec", float(k_sec1))
                shp.editColumn_double(hyd1, "e_min", float(e_min1))
                shp.editColumn_double(hyd1, "e_max", float(e_max1))
                shp.editColumn_double(hyd1, "e_sec", float(e_sec1))
            
                shp.editColumn_double(hyd2, "E_b_ini", float(E_b_ini2))
                shp.editColumn_double(hyd2, "k_b", float(k_b2))
                shp.editColumn_double(hyd2, "E_ini", float(E_ini2))
                shp.editColumn_double(hyd2, "l", float(l2))
                shp.editColumn_double(hyd2, "alpha", float(alpha2))
                shp.editColumn_double(hyd2, "k_e", float(k_e2))
                shp.editColumn_double(hyd2, "k_is", float(k_is2))
                shp.editColumn_double(hyd2, "k_sec", float(k_sec2))
                shp.editColumn_double(hyd2, "e_min", float(e_min2))
                shp.editColumn_double(hyd2, "e_max", float(e_max2))
                shp.editColumn_double(hyd2, "e_sec", float(e_sec2))
            
                shp.editColumn_double(hyd3, "E_b_ini", float(E_b_ini3))
                shp.editColumn_double(hyd3, "k_b", float(k_b3))
                shp.editColumn_double(hyd3, "E_ini", float(E_ini3))
                shp.editColumn_double(hyd3, "l", float(l3))
                shp.editColumn_double(hyd3, "alpha", float(alpha3))
                shp.editColumn_double(hyd3, "k_e", float(k_e3))
                shp.editColumn_double(hyd3, "k_is", float(k_is3))
                shp.editColumn_double(hyd3, "k_sec", float(k_sec3))
                shp.editColumn_double(hyd3, "e_min", float(e_min3))
                shp.editColumn_double(hyd3, "e_max", float(e_max3))
                shp.editColumn_double(hyd3, "e_sec", float(e_sec3))    
                    
            elif nrHydrotopes == 4:
                
                vlayer1 = hyd1
                vlayer2 = hyd2
                vlayer3 = hyd3
                vlayer4 = hyd4
                
                shp.addColumn_double(hyd1, "E_b_ini")
                shp.addColumn_double(hyd1, "k_b")
                shp.addColumn_double(hyd1, "E_ini")
                shp.addColumn_double(hyd1, "l" )
                shp.addColumn_double(hyd1, "alpha")
                shp.addColumn_double(hyd1, "k_e") 
                shp.addColumn_double(hyd1, "k_is")
                shp.addColumn_double(hyd1, "k_sec")
                shp.addColumn_double(hyd1, "e_min")
                shp.addColumn_double(hyd1, "e_max")
                shp.addColumn_double(hyd1, "e_sec")    

                shp.addColumn_double(hyd2, "E_b_ini")
                shp.addColumn_double(hyd2, "k_b")
                shp.addColumn_double(hyd2, "E_ini")
                shp.addColumn_double(hyd2, "l" )
                shp.addColumn_double(hyd2, "alpha")
                shp.addColumn_double(hyd2, "k_e") 
                shp.addColumn_double(hyd2, "k_is")
                shp.addColumn_double(hyd2, "k_sec")
                shp.addColumn_double(hyd2, "e_min")
                shp.addColumn_double(hyd2, "e_max")
                shp.addColumn_double(hyd2, "e_sec")

                shp.addColumn_double(hyd3, "E_b_ini")
                shp.addColumn_double(hyd3, "k_b")
                shp.addColumn_double(hyd3, "E_ini")
                shp.addColumn_double(hyd3, "l" )
                shp.addColumn_double(hyd3, "alpha")
                shp.addColumn_double(hyd3, "k_e") 
                shp.addColumn_double(hyd3, "k_is")
                shp.addColumn_double(hyd3, "k_sec")
                shp.addColumn_double(hyd3, "e_min")
                shp.addColumn_double(hyd3, "e_max")
                shp.addColumn_double(hyd3, "e_sec")

                shp.addColumn_double(hyd4, "E_b_ini")
                shp.addColumn_double(hyd4, "k_b")
                shp.addColumn_double(hyd4, "E_ini")
                shp.addColumn_double(hyd4, "l" )
                shp.addColumn_double(hyd4, "alpha")
                shp.addColumn_double(hyd4, "k_e") 
                shp.addColumn_double(hyd4, "k_is")
                shp.addColumn_double(hyd4, "k_sec")
                shp.addColumn_double(hyd4, "e_min")
                shp.addColumn_double(hyd4, "e_max")
                shp.addColumn_double(hyd4, "e_sec")
                
                shp.editColumn_double(hyd1, "E_b_ini", float(E_b_ini1))
                shp.editColumn_double(hyd1, "k_b", float(k_b1))
                shp.editColumn_double(hyd1, "E_ini", float(E_ini1))
                shp.editColumn_double(hyd1, "l", float(l1))
                shp.editColumn_double(hyd1, "alpha", float(alpha1))
                shp.editColumn_double(hyd1, "k_e", float(k_e1))
                shp.editColumn_double(hyd1, "k_is", float(k_is1))
                shp.editColumn_double(hyd1, "k_sec", float(k_sec1))
                shp.editColumn_double(hyd1, "e_min", float(e_min1))
                shp.editColumn_double(hyd1, "e_max", float(e_max1))
                shp.editColumn_double(hyd1, "e_sec", float(e_sec1))
            
                shp.editColumn_double(hyd2, "E_b_ini", float(E_b_ini2))
                shp.editColumn_double(hyd2, "k_b", float(k_b2))
                shp.editColumn_double(hyd2, "E_ini", float(E_ini2))
                shp.editColumn_double(hyd2, "l", float(l2))
                shp.editColumn_double(hyd2, "alpha", float(alpha2))
                shp.editColumn_double(hyd2, "k_e", float(k_e2))
                shp.editColumn_double(hyd2, "k_is", float(k_is2))
                shp.editColumn_double(hyd2, "k_sec", float(k_sec2))
                shp.editColumn_double(hyd2, "e_min", float(e_min2))
                shp.editColumn_double(hyd2, "e_max", float(e_max2))
                shp.editColumn_double(hyd2, "e_sec", float(e_sec2))
            
                shp.editColumn_double(hyd3, "E_b_ini", float(E_b_ini3))
                shp.editColumn_double(hyd3, "k_b", float(k_b3))
                shp.editColumn_double(hyd3, "E_ini", float(E_ini3))
                shp.editColumn_double(hyd3, "l", float(l3))
                shp.editColumn_double(hyd3, "alpha", float(alpha3))
                shp.editColumn_double(hyd3, "k_e", float(k_e3))
                shp.editColumn_double(hyd3, "k_is", float(k_is3))
                shp.editColumn_double(hyd3, "k_sec", float(k_sec3))
                shp.editColumn_double(hyd3, "e_min", float(e_min3))
                shp.editColumn_double(hyd3, "e_max", float(e_max3))
                shp.editColumn_double(hyd3, "e_sec", float(e_sec3))          
                
                shp.editColumn_double(hyd4, "E_b_ini", float(E_b_ini4))
                shp.editColumn_double(hyd4, "k_b", float(k_b4))
                shp.editColumn_double(hyd4, "E_ini", float(E_ini4))
                shp.editColumn_double(hyd4, "l", float(l4))
                shp.editColumn_double(hyd4, "alpha", float(alpha4))
                shp.editColumn_double(hyd4, "k_e", float(k_e4))
                shp.editColumn_double(hyd4, "k_is", float(k_is4))
                shp.editColumn_double(hyd4, "k_sec", float(k_sec4))
                shp.editColumn_double(hyd4, "e_min", float(e_min4))
                shp.editColumn_double(hyd4, "e_max", float(e_max4))
                shp.editColumn_double(hyd4, "e_sec", float(e_sec4))          
                
            else:
                QMessageBox.warning(self, self.tr("Warning"), self.tr('No valid number of hydrotopes! Only 1-4'))
    
        except Exception as e:
            print e
            self.gui.popup_error_message(self.gui.tr("An error occurred with loading data to hydrotopes attribute table:\n {}").format(e))
             

    def get_params(self): 
        """
            Reads params from QlineEdits.
        """
    
        try:
            if nrHydrotopes == 1:    
                #hyd1 = str.freewat.ftools_utils.getMapLayerByName(unicode(self.listSourceLayer.currentText()))
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer11.currentText()))
                
                E_b_ini1_t = self.gui.inputE_b_ini_1.text()
                k_b1_t = self.gui.inputk_b_1.text()
                
                E_ini1_t = self.gui.inputE_ini_11.text()
                l1_t = self.gui.input_l_11.text()
                alpha1_t = self.gui.inputalpha_11.text()
                k_e1_t = self.gui.inputk_e_11.text()
                k_is1_t = self.gui.inputk_is_11.text()
                k_sec1_t = self.gui.inputk_sec_11.text()
                e_min1_t = self.gui.inpute_min_11.text()
                e_max1_t = self.gui.inpute_max_11.text()
                e_sec1_t = self.gui.inpute_sec_11.text()

                E_b_ini1 = float(E_b_ini1_t)
                k_b1 = float(k_b1_t)
                
                E_ini1 = float(E_ini1_t)
                l1 = float(l1_t)
                alpha1 = float(alpha1_t)
                k_e1 = float(k_e1_t)
                k_is1 = float(k_is1_t)
                k_sec1 = float(k_sec1_t)
                e_min1 = float(e_min1_t)
                e_max1 = float(e_max1_t)
                e_sec1 = float(e_sec1_t)
                
            elif nrHydrotopes == 2:
            
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer21.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer22.currentText()))
            
                E_b_ini2_t = self.gui.inputE_b_ini_2.text()
                k_b2_t = self.gui.inputk_b_2.text()
                
                E_ini1_t = self.gui.inputE_ini_21.text()
                l1_t = self.gui.input_l_21.text()
                alpha1_t = self.gui.inputalpha_21.text()
                k_e1_t = self.gui.inputk_e_21.text()
                k_is1_t = self.gui.inputk_is_21.text()
                k_sec1_t = self.gui.inputk_sec_21.text()
                e_min1_t = self.gui.inpute_min_21.text()
                e_max1_t = self.gui.inpute_max_21.text()
                e_sec1_t = self.gui.inpute_sec_21.text()
                
                E_ini2_t = self.gui.inputE_ini_22.text()
                l2_t = self.gui.input_l_22.text()
                alpha2_t = self.gui.inputalpha_22.text()
                k_e2_t = self.gui.inputk_e_22.text()
                k_is2_t = self.gui.inputk_is_22.text()
                k_sec2_t = self.gui.inputk_sec_22.text()
                e_min2_t = self.gui.inpute_min_22.text()
                e_max2_t = self.gui.inpute_max_22.text()
                e_sec2_t = self.gui.inpute_sec_22.text()                

                E_b_ini2 = float(E_b_ini2_t)
                k_b2 = float(k_b2_t)
                
                E_ini1 = float(E_ini1_t)
                l1 = float(l1_t)
                alpha1 = float(alpha1_t)
                k_e1 = float(k_e1_t)
                k_is1 = float(k_is1_t)
                k_sec1 = float(k_sec1_t)
                e_min1 = float(e_min1_t)
                e_max1 = float(e_max1_t)
                e_sec1 = float(e_sec1_t)
                
                E_ini2 = float(E_ini2_t)
                l2 = float(l2_t)
                alpha2 = float(alpha2_t)
                k_e2 = float(k_e2_t)
                k_is2 = float(k_is2_t)
                k_sec2 = float(k_sec2_t)
                e_min2 = float(e_min2_t)
                e_max2 = float(e_max2_t)
                e_sec2 = float(e_sec2_t)
                                
                
            elif nrHydrotopes == 3:
            
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer31.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer32.currentText()))
                hyd3 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer33.currentText()))
            
                E_b_ini3_t = self.gui.inputE_b_ini_3.text()
                k_b3_t = self.gui.inputk_b_3.text()
                
                E_ini1_t = self.gui.inputE_ini_31.text()
                l1_t = self.gui.input_l_31.text()
                alpha1_t = self.gui.inputalpha_31.text()
                k_e1_t = self.gui.inputk_e_31.text()
                k_is1_t = self.gui.inputk_is_31.text()
                k_sec1_t = self.gui.inputk_sec_31.text()
                e_min1_t = self.gui.inpute_min_31.text()
                e_max1_t = self.gui.inpute_max_31.text()
                e_sec1_t = self.gui.inpute_sec_31.text()
                
                E_ini2_t = self.gui.inputE_ini_32.text()
                l2_t = self.gui.input_l_32.text()
                alpha2_t = self.gui.inputalpha_32.text()
                k_e2_t = self.gui.inputk_e_32.text()
                k_is2_t = self.gui.inputk_is_32.text()
                k_sec2_t = self.gui.inputk_sec_32.text()
                e_min2_t = self.gui.inpute_min_32.text()
                e_max2_t = self.gui.inpute_max_32.text()
                e_sec2_t = self.gui.inpute_sec_32.text()                
                
                E_ini3_t = self.gui.inputE_ini_33.text()
                l3_t = self.gui.input_l_33.text()
                alpha3_t = self.gui.inputalpha_33.text()
                k_e3_t = self.gui.inputk_e_33.text()
                k_is3_t = self.gui.inputk_is_33.text()
                k_sec3_t = self.gui.inputk_sec_33.text()
                e_min3_t = self.gui.inpute_min_33.text()
                e_max3_t = self.gui.inpute_max_33.text()
                e_sec3_t = self.gui.inpute_sec_33.text()                

                E_b_ini3 = float(E_b_ini3_t)
                k_b3 = float(k_b3_t)
                
                E_ini1 = float(E_ini1_t)
                l1 = float(l1_t)
                alpha1 = float(alpha1_t)
                k_e1 = float(k_e1_t)
                k_is1 = float(k_is1_t)
                k_sec1 = float(k_sec1_t)
                e_min1 = float(e_min1_t)
                e_max1 = float(e_max1_t)
                e_sec1 = float(e_sec1_t)
                
                E_ini2 = float(E_ini2_t)
                l2 = float(l2_t)
                alpha2 = float(alpha2_t)
                k_e2 = float(k_e2_t)
                k_is2 = float(k_is2_t)
                k_sec2 = float(k_sec2_t)
                e_min2 = float(e_min2_t)
                e_max2 = float(e_max2_t)
                e_sec2 = float(e_sec2_t) 
                
                E_ini3 = float(E_ini3_t)
                l3 = float(l3_t)
                alpha3 = float(alpha3_t)
                k_e3 = float(k_e3_t)
                k_is3 = float(k_is3_t)
                k_sec3 = float(k_sec3_t)
                e_min3 = float(e_min3_t)
                e_max3 = float(e_max3_t)
                e_sec3 = float(e_sec3_t) 
                        
                
            elif nrHydrotopes == 4:        
            
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer41.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer42.currentText()))
                hyd3 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer43.currentText()))
                hyd4 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer44.currentText()))
            
                E_b_ini4_t = self.gui.inputE_b_ini_4.text()
                k_b4_t = self.gui.inputk_b_4.text()
                
                E_ini1_t = self.gui.inputE_ini_41.text()
                l1_t = self.gui.input_l_41.text()
                alpha1_t = self.gui.inputalpha_41.text()
                k_e1_t = self.gui.inputk_e_41.text()
                k_is1_t = self.gui.inputk_is_41.text()
                k_sec1_t = self.gui.inputk_sec_41.text()
                e_min1_t = self.gui.inpute_min_41.text()
                e_max1_t = self.gui.inpute_max_41.text()
                e_sec1_t = self.gui.inpute_sec_41.text()
                
                E_ini2_t = self.gui.inputE_ini_42.text()
                l2_t = self.gui.input_l_42.text()
                alpha2_t = self.gui.inputalpha_42.text()
                k_e2_t = self.gui.inputk_e_42.text()
                k_is2_t = self.gui.inputk_is_42.text()
                k_sec2_t = self.gui.inputk_sec_42.text()
                e_min2_t = self.gui.inpute_min_42.text()
                e_max2_t = self.gui.inpute_max_42.text()
                e_sec2_t = self.gui.inpute_sec_42.text()                
                
                E_ini3_t = self.gui.inputE_ini_43.text()
                l3_t = self.gui.input_l_43.text()
                alpha3_t = self.gui.inputalpha_43.text()
                k_e3_t = self.gui.inputk_e_43.text()
                k_is3_t = self.gui.inputk_is_43.text()
                k_sec3_t = self.gui.inputk_sec_43.text()
                e_min3_t = self.gui.inpute_min_43.text()
                e_max3_t = self.gui.inpute_max_43.text()
                e_sec3_t = self.gui.inpute_sec_43.text()                
                
                E_ini3_t = self.gui.inputE_ini_44.text()
                l3_t = self.gui.input_l_44.text()
                alpha3_t = self.gui.inputalpha_44.text()
                k_e3_t = self.gui.inputk_e_44.text()
                k_is3_t = self.gui.inputk_is_44.text()
                k_sec3_t = self.gui.inputk_sec_44.text()
                e_min3_t = self.gui.inpute_min_44.text()
                e_max3_t = self.gui.inpute_max_44.text()
                e_sec3_t = self.gui.inpute_sec_44.text()                

                E_b_ini4 = float(E_b_ini4_t)
                k_b4 = float(k_b4_t)
                
                E_ini1 = float(E_ini1_t)
                l1 = float(l1_t)
                alpha1 = float(alpha1_t)
                k_e1 = float(k_e1_t)
                k_is1 = float(k_is1_t)
                k_sec1 = float(k_sec1_t)
                e_min1 = float(e_min1_t)
                e_max1 = float(e_max1_t)
                e_sec1 = float(e_sec1_t)
                
                E_ini2 = float(E_ini2_t)
                l2 = float(l2_t)
                alpha2 = float(alpha2_t)
                k_e2 = float(k_e2_t)
                k_is2 = float(k_is2_t)
                k_sec2 = float(k_sec2_t)
                e_min2 = float(e_min2_t)
                e_max2 = float(e_max2_t)
                e_sec2 = float(e_sec2_t) 
                
                E_ini3 = float(E_ini3_t)
                l3 = float(l3_t)
                alpha3 = float(alpha3_t)
                k_e3 = float(k_e3_t)
                k_is3 = float(k_is3_t)
                k_sec3 = float(k_sec3_t)
                e_min3 = float(e_min3_t)
                e_max3 = float(e_max3_t)
                e_sec3 = float(e_sec3_t) 
                
                E_ini4 = float(E_ini4_t)
                l4 = float(l4_t)
                alpha4 = float(alpha4_t)
                k_e4 = float(k_e4_t)
                k_is4 = float(k_is4_t)
                k_sec4 = float(k_sec4_t)
                e_min4 = float(e_min4_t)
                e_max4 = float(e_max4_t)
                e_sec4 = float(e_sec4_t) 
                                                
                
            else:
                QMessageBox.warning(self, self.tr("Warning"), self.tr('No valid number of hydrotopes! Only 1-4'))
    
        except Exception as e:
            print e
            self.gui.popup_error_message(self.gui.tr("An error occurred with loading data to hydrotopes attribute table:\n {}").format(e))


 








            
#created, but unused functions 
            
#       -  read values from attribute table (+ set in boxes of parameters!)
    
    def read_params(vlayer, field_name):
        """
            Read parameters from hydrotope'S shapefile's attribute table
        """
        from PyQt4.QtCore import *
        layer = QgsMapLayerRegistry.instance().mapLayersByName(vlayer)[0] #geht auch ID
        iface.setActiveLayer(layer)
        fid = 1 # the second feature (zero based indexing!)
        iterator = layer.getFeatures(QgsFeatureRequest().setFilterFid(fid))
        feature = next(iterator)
        idx = layer.fieldNameIndex(field_name)
        return(feature.attributes()[idx])
        
        #layer = QgsMapLayerRegistry.instance().mapLayersByName(vlayer)[0] #geht auch ID
        #iface.setActiveLayer(layer)
        #for feature in layer.getFeatures():
            #name = feature[field_name]
            #print name    
        
        #for feature in layer.getFeatures():
            #name = feature[field_name]
            #print name
        
        #features = layer.getFeatures() #gibt pro Reihe eine Liste aus, kein Header
        #for feat in features:
            #attrs = feat.attributes()
            #print attrs[1]
    
    # read values from attribute table
    
    #from qgis.core import *
    
    #import processing
    ## Load the layer
    #layer = processing.getObject(Population)
     
    ## Write the filter expression and set it
    #query = '"pop_max" > 1000000'
    #selection = layer.getFeatures(QgsFeatureRequest().setFilterExpression(query))
    #layer.setSelectedFeatures([k.id() for k in selection])

#       -  load attribute table -> ftools_utils        

    def load_param_data(self):
        """
        Load parameters of hydrotope shapefiles
        """
        try:
            if nrHydrotopes == 1:
                
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer11.currentText()))
                    
    
                try:
                    alpha1 = self.shp.read_params(hyd1,"alpha")
                    self.inputalpha_11.setText(alpha1)
                except Exception:
                    pass
                try:
                    e_min1 = self.shp.read_params(hyd1,"e_min")
                    self.inpute_min_11.setText(e_min1)
                except Exception:
                    pass
                try:
                    k_is1 = self.shp.read_params(hyd1,"k_is")
                    self.inputk_is_11.setText(k_is1)
                except Exception:
                    pass
                try:
                    e_max1 = self.shp.read_params(hyd1,"e_max")
                    self.inpute_max_11.setText(e_max1)
                except Exception:
                    pass
                try:
                    E_ini1 = self.shp.read_params(hyd1,"E_ini")
                    self.inputE_ini_11.setText(E_ini1)
                except Exception:
                    pass
                try:
                    k_e1 = self.shp.read_params(hyd1,"k_e")
                    self.inputk_e_11.setText(k_e1)
                except Exception:
                    pass
                try:
                    l1 = self.shp.read_params(hyd1,"l")
                    self.input_l_11.setText(l1)
                except Exception:
                    pass
                try:
                    k_sec1 = self.shp.read_params(hyd1,"k_sec")
                    self.inputk_sec_11.setText(k_sec1)
                except Exception:
                    pass
                try:
                    e_sec1 = self.shp.read_params(hyd1,"e_sec")
                    self.inpute_sec_11.setText(e_sec1)
                except Exception:
                    pass
                
            elif nrHydrotopes == 2:
                
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer21.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer22.currentText()))
                
                try:
                    alpha1 = self.shp.read_params(hyd1,"alpha")
                    self.inputalpha_21.setText(alpha1)
                except Exception:
                    pass
                try:
                    e_min1 = self.shp.read_params(hyd1,"e_min")
                    self.inpute_min_21.setText(e_min1)
                except Exception:
                    pass
                try:
                    k_is1 = self.shp.read_params(hyd1,"k_is")
                    self.inputk_is_21.setText(k_is1)
                except Exception:
                    pass
                try:
                    e_max1 = self.shp.read_params(hyd1,"e_max")
                    self.inpute_max_21.setText(e_max1)
                except Exception:
                    pass
                try:
                    E_ini1 = self.shp.read_params(hyd1,"E_ini")
                    self.inputE_ini_21.setText(E_ini1)
                except Exception:
                    pass
                try:
                    k_e1 = self.shp.read_params(hyd1,"k_e")
                    self.inputk_e_21.setText(k_e1)
                except Exception:
                    pass
                try:
                    l1 = self.shp.read_params(hyd1,"l")
                    self.input_l_21.setText(l1)
                except Exception:
                    pass
                try:
                    k_sec1 = self.shp.read_params(hyd1,"k_sec")
                    self.inputk_sec_21.setText(k_sec1)
                except Exception:
                    pass
                try:
                    e_sec1 = self.shp.read_params(hyd1,"e_sec")
                    self.inpute_sec_21.setText(e_sec1)
                except Exception:
                    pass
                
                try:
                    alpha2 = self.shp.read_params(hyd2,"alpha")
                    self.inputalpha_22.setText(alpha2)
                except Exception:
                    pass
                try:
                    e_min2 = self.shp.read_params(hyd2,"e_min")
                    self.inpute_min_22.setText(e_min2)
                except Exception:
                    pass
                try:
                    k_is2 = self.shp.read_params(hyd2,"k_is")
                    self.inputk_is_22.setText(k_is2)
                except Exception:
                    pass
                try:
                    e_max2 = self.shp.read_params(hyd2,"e_max")
                    self.inpute_max_22.setText(e_max2)
                except Exception:
                    pass
                try:
                    E_ini2 = self.shp.read_params(hyd2,"E_ini")
                    self.inputE_ini_22.setText(E_ini2)
                except Exception:
                    pass
                try:
                    k_e2 = self.shp.read_params(hyd2,"k_e")
                    self.inputk_e_22.setText(k_e2)
                except Exception:
                    pass
                try:
                    l2 = self.shp.read_params(hyd2,"l")
                    self.input_l_22.setText(l2)
                except Exception:
                    pass
                try:
                    k_sec2 = self.shp.read_params(hyd2,"k_sec")
                    self.inputk_sec_22.setText(k_sec2)
                except Exception:
                    pass
                try:
                    e_sec2 = self.shp.read_params(hyd2,"e_sec")
                    self.inpute_sec_22.setText(e_sec2)
                except Exception:
                    pass    
                
            elif nrHydrotopes == 3:
    
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer31.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer32.currentText()))
                hyd3 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer33.currentText()))
                
                try:
                    alpha1 = self.shp.read_params(hyd1,"alpha")
                    self.inputalpha_31.setText(alpha1)
                except Exception:
                    pass
                try:
                    e_min1 = self.shp.read_params(hyd1,"e_min")
                    self.inpute_min_31.setText(e_min1)
                except Exception:
                    pass
                try:
                    k_is1 = self.shp.read_params(hyd1,"k_is")
                    self.inputk_is_31.setText(k_is1)
                except Exception:
                    pass
                try:
                    e_max1 = self.shp.read_params(hyd1,"e_max")
                    self.inpute_max_31.setText(e_max1)
                except Exception:
                    pass
                try:
                    E_ini1 = self.shp.read_params(hyd1,"E_ini")
                    self.inputE_ini_31.setText(E_ini1)
                except Exception:
                    pass
                try:
                    k_e1 = self.shp.read_params(hyd1,"k_e")
                    self.inputk_e_31.setText(k_e1)
                except Exception:
                    pass
                try:
                    l1 = self.shp.read_params(hyd1,"l")
                    self.input_l_31.setText(l1)
                except Exception:
                    pass
                try:
                    k_sec1 = self.shp.read_params(hyd1,"k_sec")
                    self.inputk_sec_31.setText(k_sec1)
                except Exception:
                    pass
                try:
                    e_sec1 = self.shp.read_params(hyd1,"e_sec")
                    self.inpute_sec_31.setText(e_sec1)
                except Exception:
                    pass

                try:
                    alpha2 = self.shp.read_params(hyd2,"alpha")
                    self.inputalpha_32.setText(alpha2)
                except Exception:
                    pass
                try:
                    e_min2 = self.shp.read_params(hyd2,"e_min")
                    self.inpute_min_32.setText(e_min2)
                except Exception:
                    pass
                try:
                    k_is2 = self.shp.read_params(hyd2,"k_is")
                    self.inputk_is_32.setText(k_is2)
                except Exception:
                    pass
                try:
                    e_max2 = self.shp.read_params(hyd2,"e_max")
                    self.inpute_max_32.setText(e_max2)
                except Exception:
                    pass
                try:
                    E_ini2 = self.shp.read_params(hyd2,"E_ini")
                    self.inputE_ini_32.setText(E_ini2)
                except Exception:
                    pass
                try:
                    k_e2 = self.shp.read_params(hyd2,"k_e")
                    self.inputk_e_32.setText(k_e2)
                except Exception:
                    pass
                try:
                    l2 = self.shp.read_params(hyd2,"l")
                    self.input_l_32.setText(l2)
                except Exception:
                    pass
                try:
                    k_sec2 = self.shp.read_params(hyd2,"k_sec")
                    self.inputk_sec_32.setText(k_sec2)
                except Exception:
                    pass
                try:
                    e_sec2 = self.shp.read_params(hyd2,"e_sec")
                    self.inpute_sec_32.setText(e_sec2)
                except Exception:
                    pass        



                try:
                    alpha3 = self.shp.read_params(hyd3,"alpha")
                    self.inputalpha_33.setText(alpha3)
                except Exception:
                    pass
                try:
                    e_min3 = self.shp.read_params(hyd3,"e_min")
                    self.inpute_min_33.setText(e_min3)
                except Exception:
                    pass
                try:
                    k_is3 = self.shp.read_params(hyd3,"k_is")
                    self.inputk_is_33.setText(k_is3)
                except Exception:
                    pass
                try:
                    e_max3 = self.shp.read_params(hyd3,"e_max")
                    self.inpute_max_33.setText(e_max3)
                except Exception:
                    pass
                try:
                    E_ini3 = self.shp.read_params(hyd3,"E_ini")
                    self.inputE_ini_33.setText(E_ini3)
                except Exception:
                    pass
                try:
                    k_e3 = self.shp.read_params(hyd3,"k_e")
                    self.inputk_e_33.setText(k_e3)
                except Exception:
                    pass
                try:
                    l3 = self.shp.read_params(hyd3,"l")
                    self.input_l_33.setText(l3)
                except Exception:
                    pass
                try:
                    k_sec3 = self.shp.read_params(hyd3,"k_sec")
                    self.inputk_sec_33.setText(k_sec3)
                except Exception:
                    pass
                try:
                    e_sec3 = self.shp.read_params(hyd3,"e_sec")
                    self.inpute_sec_33.setText(e_sec3)
                except Exception:
                    pass        


            elif nrHydrotopes == 4:
                
                hyd1 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer41.currentText()))
                hyd2 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer42.currentText()))
                hyd3 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer43.currentText()))
                hyd4 = str.freewat.ftools_utils.getMapLayerByName(string(self.listSourceLayer44.currentText()))
                    
    
                try:
                    alpha1 = self.shp.read_params(hyd1,"alpha")
                    self.inputalpha_41.setText(alpha1)
                except Exception:
                    pass
                try:
                    e_min1 = self.shp.read_params(hyd1,"e_min")
                    self.inpute_min_41.setText(e_min1)
                except Exception:
                    pass
                try:
                    k_is1 = self.shp.read_params(hyd1,"k_is")
                    self.inputk_is_41.setText(k_is1)
                except Exception:
                    pass
                try:
                    e_max1 = self.shp.read_params(hyd1,"e_max")
                    self.inpute_max_41.setText(e_max1)
                except Exception:
                    pass
                try:
                    E_ini1 = self.shp.read_params(hyd1,"E_ini")
                    self.inputE_ini_41.setText(E_ini1)
                except Exception:
                    pass
                try:
                    k_e1 = self.shp.read_params(hyd1,"k_e")
                    self.inputk_e_41.setText(k_e1)
                except Exception:
                    pass
                try:
                    l1 = self.shp.read_params(hyd1,"l")
                    self.input_l_41.setText(l1)
                except Exception:
                    pass
                try:
                    k_sec1 = self.shp.read_params(hyd1,"k_sec")
                    self.inputk_sec_41.setText(k_sec1)
                except Exception:
                    pass
                try:
                    e_sec1 = self.shp.read_params(hyd1,"e_sec")
                    self.inpute_sec_41.setText(e_sec1)
                except Exception:
                    pass


                try:
                    alpha2 = self.shp.read_params(hyd2,"alpha")
                    self.inputalpha_42.setText(alpha2)
                except Exception:
                    pass

                try:
                    e_min2 = self.shp.read_params(hyd2,"e_min")
                    self.inpute_min_42.setText(e_min2)
                except Exception:
                    pass
                try:
                    k_is2 = self.shp.read_params(hyd2,"k_is")
                    self.inputk_is_42.setText(k_is2)
                except Exception:
                    pass
                try:
                    e_max2 = self.shp.read_params(hyd2,"e_max")
                    self.inpute_max_42.setText(e_max2)
                except Exception:
                    pass
                try:
                    E_ini2 = self.shp.read_params(hyd2,"E_ini")
                    self.inputE_ini_42.setText(E_ini2)
                except Exception:
                    pass
                try:
                    k_e2 = self.shp.read_params(hyd2,"k_e")
                    self.inputk_e_42.setText(k_e2)
                except Exception:
                    pass
                try:
                    l2 = self.shp.read_params(hyd2,"l")
                    self.input_l_42.setText(l2)
                except Exception:
                    pass
                try:
                    k_sec2 = self.shp.read_params(hyd2,"k_sec")
                    self.inputk_sec_42.setText(k_sec2)
                except Exception:
                    pass
                try:
                    e_sec2 = self.shp.read_params(hyd2,"e_sec")
                    self.inpute_sec_42.setText(e_sec2)
                except Exception:
                    pass        


                try:
                    alpha3 = self.shp.read_params(hyd3,"alpha")
                    self.inputalpha_43.setText(alpha3)
                except Exception:
                    pass
                try:
                    e_min3 = self.shp.read_params(hyd3,"e_min")
                    self.inpute_min_43.setText(e_min3)
                except Exception:
                    pass
                try:
                    k_is3 = self.shp.read_params(hyd3,"k_is")
                    self.inputk_is_43.setText(k_is3)
                except Exception:
                    pass
                try:
                    e_max3 = self.shp.read_params(hyd3,"e_max")
                    self.inpute_max_43.setText(e_max3)
                except Exception:
                    pass
                try:
                    E_ini3 = self.shp.read_params(hyd3,"E_ini")
                    self.inputE_ini_43.setText(E_ini3)
                except Exception:
                    pass
                try:
                    k_e3 = self.shp.read_params(hyd3,"k_e")
                    self.inputk_e_43.setText(k_e3)
                except Exception:
                    pass
                try:
                    l3 = self.shp.read_params(hyd3,"l")
                    self.input_l_43.setText(l3)
                except Exception:
                    pass
                try:
                    k_sec3 = self.shp.read_params(hyd3,"k_sec")
                    self.inputk_sec_43.setText(k_sec3)
                except Exception:
                    pass
                try:
                    e_sec3 = self.shp.read_params(hyd3,"e_sec")
                    self.inpute_sec_43.setText(e_sec3)
                except Exception:
                    pass        
    
    
                try:
                    alpha4 = self.shp.read_params(hyd4,"alpha")
                    self.inputalpha_44.setText(alpha4)
                except Exception:
                    pass
                try:
                    e_min4 = self.shp.read_params(hyd4,"e_min")
                    self.inpute_min_44.setText(e_min4)
                except Exception:
                    pass
                try:
                    k_is4 = self.shp.read_params(hyd4,"k_is")
                    self.inputk_is_44.setText(k_is4)
                except Exception:
                    pass
                try:
                    e_max4 = self.shp.read_params(hyd4,"e_max")
                    self.inpute_max_44.setText(e_max4)
                except Exception:
                    pass
                try:
                    E_ini4 = self.shp.read_params(hyd4,"E_ini")
                    self.inputE_ini_44.setText(E_ini4)
                except Exception:
                    pass
                try:
                    k_e4 = self.shp.read_params(hyd4,"k_e")
                    self.inputk_e_44.setText(k_e4)
                except Exception:
                    pass
                try:
                    l4 = self.shp.read_params(hyd4,"l")
                    self.input_l_44.setText(l4)
                except Exception:
                    pass
                try:
                    k_sec4 = self.shp.read_params(hyd4,"k_sec")
                    self.inputk_sec_44.setText(k_sec4)
                except Exception:
                    pass
                try:
                    e_sec4 = self.shp.read_params(hyd4,"e_sec")
                    self.inpute_sec_44.setText(e_sec4)
                except Exception:
                    pass        
        
            else:
                QMessageBox.warning(self, self.tr("Warning"), self.tr('No valid number of hydrotopes! Only 1-4'))
    
        except Exception as e:
            print e
            self.gui.popup_error_message(self.gui.tr("An error occurred with loading data from hydrotopes attribute table:\n {}").format(e))


            

                
      