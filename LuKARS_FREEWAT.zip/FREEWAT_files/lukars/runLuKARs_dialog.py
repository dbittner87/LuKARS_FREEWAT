# -*- coding: utf-8 -*-
# ===============================================================================
#
#
# Copyright (c) 2015 IST-SUPSI (www.supsi.ch/ist)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
#
# ===============================================================================

import base_functions as basefun
import config
import ftools_utils
import params_csvManager as params_csv
import shpManager
import pandas as pd
import numpy as np
import plot

#from tkinter import filedialog as fd
from PyQt4.QtCore import QDateTime, Qt, QVariant
from PyQt4.QtGui import QDialog, QFileDialog, QInputDialog, QMessageBox, QPlainTextEdit
from PyQt4.QtGui import QDialog, QIcon, QMessageBox, QDialogButtonBox
from PyQt4 import uic
from qgis.core import QgsDataSourceURI, QgsMapLayerRegistry, QgsVectorLayer, QgsField, QgsUnitTypes

from oat.plugin.process.saveSensorList_dialog import SaveSensorList as SensList
from oat.plugin import databaseManager
from oat.oatlib import sensor
from oat.plugin.matplotWidget import MatplotWidget
from oat.plugin.process import imagePlayer
from oat.plugin.process import processThread
from oat.plugin.process import processTs_dialog as oatTs
#from oat.plugin.createSensor.create import csvManager

from freewat.freewat_utils  import getVectorLayerByName, getVectorLayerNames, getFieldNames
from pyspatialite import dbapi2 as sqlite3


import os
import copy

FORM_CLASS, _ = uic.loadUiType(os.path.join(config.ui_path, 'runmodel.ui'))

#Functions:
#    - Cancel
#    - Load sensors
#    - Nr. Hydrotopes -> stackedWidget_shps & stackedWidget_param
#    - Input Hydrotope shps --> shpManager
#    - Snow model, Interception , Evapotranspiration
#    - Warm up-, Calibration period + Validation period
#    - load Parameter from shapes 
#    - Input file parameters (csv) --> params_csvManager
#    - Check Validity: Check if everything correctly assigned and then enable Define Parameters tab
#    - Plot results
#    - Run model (+Read parameters 2nd tab)
#    - Take parameters on to hydrotope shapefiles' attribute table

class RunLuKARsDialog(QDialog, FORM_CLASS):
    """
        Set up LuKARS model gui manager
    """

#    exception = pyqtSignal(Exception)
#    popupMessage = pyqtSignal(str)
    
    def __init__(self, iface):
        QDialog.__init__(self)
        # iface qgis interface
        self.iface = iface
        self.setupUi(self)

        self.db = databaseManager.DatabaseManager()
        self.loaded_sensor = {}
        
        self.result = {
            'type': None
        }
        
        self.precip = None
        self.temp = None
        self.discharge = None
        
        self.params = None

        self.shp = shpManager.ShpManager(self)
        self.csv = params_csv.Params(self)
        self.plot = plot.Window(self)

#        self.clear_layout(self.chartLayout.layout())
        self.stackedWidget_shps.setCurrentIndex(3)
        self.stackedWidget_param.setCurrentIndex(3)
        self.snow_model_params.setCurrentIndex(3)
        self.interception_threshold.setCurrentIndex(3)        

#        self.setSnowModelOn.isChecked() #funktioniert nicht
        self.selected = "On" #funktioniert nicht- zu viele "On"s?

        # sets initial number of hydrotopes (= 1)
        self.setnr_hydrot()
        
        self.manage_gui()
        
        try:
            self.load_sensor_list()
        except Exception as e:
            QMessageBox.warning(self, self.tr("Warning"), self.tr('No sensor found!!! First load sensor into OAT.'))
            print e
            
                			
    def manage_gui(self):
        """
			init GUi
            Connect all required signals
		"""

        # clear all hydrotope input dropdown fields
        
        self.listSourceLayer11.clear()
        self.listSourceLayer21.clear()
        self.listSourceLayer22.clear()
        self.listSourceLayer31.clear()
        self.listSourceLayer32.clear()
        self.listSourceLayer33.clear()
        self.listSourceLayer41.clear()
        self.listSourceLayer42.clear()
        self.listSourceLayer43.clear()
        self.listSourceLayer44.clear()

        # show all vector shapefiles of current project in hydrotope dropdown fields
        
        layerNameList = getVectorLayerNames()
        layerNameList.sort()

        self.listSourceLayer11.addItems(layerNameList)
        self.listSourceLayer21.addItems(layerNameList)
        self.listSourceLayer22.addItems(layerNameList)
        self.listSourceLayer31.addItems(layerNameList)
        self.listSourceLayer32.addItems(layerNameList)
        self.listSourceLayer33.addItems(layerNameList)
        self.listSourceLayer41.addItems(layerNameList)
        self.listSourceLayer42.addItems(layerNameList)
        self.listSourceLayer43.addItems(layerNameList)
        self.listSourceLayer44.addItems(layerNameList)

        
        # Set hydrotope number     
        self.setNrHydrotopes.valueChanged.connect(self.setnr_hydrot) 
        #self.toolButton.clicked.connect(self.point_from_map) #if Hydrotope directly chosen from map

        # Define parameters tab by default set to unabled
        self.Define_parameters.setEnabled(False)
        
        # Add parameters file
        self.addCsvFile.clicked.connect(self.open_csv_finder)
        self.loadCsvFile.clicked.connect(self.load_csv_data) 
        #separator: Is called in params_csvManagers
        self.buttonTakeParamsShp.clicked.connect(self.load_param) 
        self.buttonCancel.clicked.connect(self.close)
        self.buttonCancel_2.clicked.connect(self.close)
        self.buttonCheckValidity.clicked.connect(self.check_validity) 
        self.buttonRun.clicked.connect(self.run)
        self.buttonTakeHydrotopes.clicked.connect(self.take_on)
        self.buttonSaveSimResults.clicked.connect(self.save_to_csv)

        
        # Toggle radiobuttons of snow and interception model
        self.setSnowModelOff.toggled.connect(lambda: self.toggle_button_snow(self.setSnowModelOff))        
        self.setInterceptionOff.toggled.connect(lambda: self.toggle_button_intercep(self.setInterceptionOff))
        
    def save_to_csv(self): #in Datei sensor.py
        """
        Write oat data to csv file

        Args:
            filepath (str): file path to save
        """
        nrHydrotopes = self.setNrHydrotopes.value()
        
        precip = self.selectPrecip.currentText()
        temp = self.selectTemp.currentText()
        discharge = self.selectDischarge.currentText() 

        # load sensor data for precipitation, temperature and discharge sensor
        self.precip = self.get_sensor_from_db(precip)
        self.temp = self.get_sensor_from_db(temp)
        self.discharge = self.get_sensor_from_db(discharge)

        # create data frame and clear data
        frame = pd.concat([self.precip.ts['data'], self.temp.ts['data'], 
                           self.discharge.ts['data']], axis=1).dropna()
        
        frame.columns = ['P', 'T', 'Q']

        # get dates for warm-up period from GUI
        warm_begin = self.warmUpBegin.date().toPyDate()
        
        # get dates for calibration period from GUI
        cal_begin = self.calibrateBegin.date().toPyDate()
        cal_end = self.calibrateEnd.date().toPyDate()
        period_c = basefun.model_period(cal_begin, cal_end, 'D')
        
        # get dates for validation period from GUI
        val_begin = self.validateBegin.date().toPyDate()
        val_end = self.validateEnd.date().toPyDate()
        period_v = basefun.model_period(val_begin, val_end, 'D')
        
        
                
        # create input frame
        frame = frame.loc[warm_begin:val_end]       
        period_model = basefun.model_period(warm_begin, val_end, 'D')
        
        
        if nrHydrotopes == 1:
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer11.currentText())
                
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T'])   
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                

                elif self.setInterceptionOn.isChecked == True:
        
                    try:
                        ic_threshold_11 = float(self.inputInt_threshold_11.text())    
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) 


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = None)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = None)                
    
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_11 = float(self.inputMeltFactor_11.text())
                    temp_threshold_11 = float(self.inputMeltingThreshold_11.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt        = basefun.t_index_model(frame['T'], mf_11, temp_threshold_11)
                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T'])    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_11 = float(self.inputInt_threshold_11.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)                        


            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1)
            perc_rech_area_1 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1)
            
            input_parameters = [rech_area, float(self.E_b_ini_1.text()), float(self.k_b_1.text()), perc_rech_area_1, 
                                float(self.l_11.text()), float(self.k_e_11.text()), float(self.E_ini_11.text()), 
                                float(self.e_min_11.text()), float(self.e_max_11.text()), float(self.alpha_11.text()), 
                                float(self.k_is_11.text()), float(self.k_sec_11.text()), float(self.e_sec_11.text())]
                                  
            
           # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e                                

        if nrHydrotopes == 2:        
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer21.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer22.currentText())
                            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                                        
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_21 = float(self.inputInt_threshold_21.text())
                        ic_threshold_22 = float(self.inputInt_threshold_22.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = None)
                
                    elif self.setEvapoOn.isCheked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = None)        
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_21.text())
                    
                    temp_threshold_21 = float(self.inputMeltingThreshold_21.text())

                    mf_2 = float(self.inputMeltFactor_22.text())
                    
                    temp_threshold_22 = float(self.inputMeltingThreshold_22.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_21) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_22) #t_index_model(temperature_ts, melt_factor, t_threshold)
                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_21 = float(self.inputInt_threshold_21.text())
                        
                        ic_threshold_22 = float(self.inputInt_threshold_22.text())
                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                        
            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2)
            perc_rech_area_1, perc_rech_area_2 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2)
            
            input_parameters = [rech_area, float(self.E_b_ini_2.text()), float(self.k_b_2.text()), perc_rech_area_1, 
                                float(self.l_21.text()), float(self.k_e_21.text()), float(self.E_ini_21.text()), 
                                float(self.e_min_21.text()), float(self.e_max_21.text()), float(self.alpha_21.text()), 
                                float(self.k_is_21.text()), float(self.k_sec_21.text()), float(self.e_sec_21.text()),
                                perc_rech_area_2, float(self.l_22.text()), float(self.k_e_22.text()), float(self.E_ini_22.text()), 
                                float(self.e_min_22.text()), float(self.e_max_22.text()), float(self.alpha_22.text()), 
                                float(self.k_is_22.text()), float(self.k_sec_22.text()), float(self.e_sec_22.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2) 
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    


        if nrHydrotopes == 3:        
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer31.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer32.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer33.currentText())
                            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                                        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                


                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_31 = float(self.inputInt_threshold_31.text())
                        ic_threshold_32 = float(self.inputInt_threshold_32.text())  
                        ic_threshold_33 = float(self.inputInt_threshold_33.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_31, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_32, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_33, 
                                        temperature_ts = frame['T'], t_threshold = None)
                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_31, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_32, 
                                        temperature_ts = frame['T'], t_threshold = None)        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = None)    
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_31.text())
                    
                    temp_threshold_31 = float(self.inputMeltingThreshold_31.text())

                    mf_2 = float(self.inputMeltFactor_32.text())
                    
                    temp_threshold_32 = float(self.inputMeltingThreshold_32.text())

                    mf_3 = float(self.inputMeltFactor_33.text())
                    
                    temp_threshold_33 = float(self.inputMeltingThreshold_33.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_31) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_32) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_3        = basefun.t_index_model(frame['T'], mf_3, temp_threshold_33) #t_index_model(temperature_ts, melt_factor, t_threshold)                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)
                            
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_31 = float(self.inputInt_threshold_31.text())
                        
                        ic_threshold_32 = float(self.inputInt_threshold_32.text())
                        
                        ic_threshold_33 = float(self.inputInt_threshold_33.text())
                                                    
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_31,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_32,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)
                        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_31,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_32,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)                        

            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2, hyd3)
            perc_rech_area_1, perc_rech_area_2, perc_rech_area_3 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2, hyd3)
            
            input_parameters = [rech_area, float(self.E_b_ini_3.text()), float(self.k_b_3.text()), perc_rech_area_1, 
                                float(self.l_31.text()), float(self.k_e_31.text()), float(self.E_ini_31.text()), 
                                float(self.e_min_31.text()), float(self.e_max_31.text()), float(self.alpha_31.text()), 
                                float(self.k_is_31.text()), float(self.k_sec_31.text()), float(self.e_sec_31.text()),
                                perc_rech_area_2, float(self.l_32.text()), float(self.k_e_32.text()), float(self.E_ini_32.text()), 
                                float(self.e_min_32.text()), float(self.e_max_32.text()), float(self.alpha_32.text()), 
                                float(self.k_is_32.text()), float(self.k_sec_32.text()), float(self.e_sec_32.text()),
                                perc_rech_area_3, float(self.l_33.text()), float(self.k_e_33.text()), float(self.E_ini_33.text()), 
                                float(self.e_min_33.text()), float(self.e_max_33.text()), float(self.alpha_33.text()), 
                                float(self.k_is_33.text()), float(self.k_sec_33.text()), float(self.e_sec_33.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2, sns_term_3)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    



        if nrHydrotopes == 4:        
                                                        
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer41.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer42.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer43.currentText())
            hyd4 = ftools_utils.getMapLayerByName(self.listSourceLayer44.currentText())
            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                                                                    
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                


                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_41 = float(self.inputInt_threshold_41.text())
                        ic_threshold_42 = float(self.inputInt_threshold_42.text())
                        ic_threshold_43 = float(self.inputInt_threshold_43.text()) 
                        ic_threshold_44 = float(self.inputInt_threshold_44.text())   
                                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = None)
                                                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = None)        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = None)    
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = None)    
                                                
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_41.text())
                    
                    temp_threshold_41 = float(self.inputMeltingThreshold_41.text())

                    mf_2 = float(self.inputMeltFactor_42.text())
                    
                    temp_threshold_42 = float(self.inputMeltingThreshold_42.text())

                    mf_3 = float(self.inputMeltFactor_43.text())
                    
                    temp_threshold_43 = float(self.inputMeltingThreshold_43.text())
                    
                    mf_4 = float(self.inputMeltFactor_44.text())
                    
                    temp_threshold_44 = float(self.inputMeltingThreshold_44.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_41) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_42) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_3        = basefun.t_index_model(frame['T'], mf_3, temp_threshold_43) #t_index_model(temperature_ts, melt_factor, t_threshold)                
                melt_4        = basefun.t_index_model(frame['T'], mf_4, temp_threshold_43) #t_index_model(temperature_ts, melt_factor, t_threshold)                
                    
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_4,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)
                                            
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)                
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_4,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_41 = float(self.inputInt_threshold_41.text())
                        
                        ic_threshold_42 = float(self.inputInt_threshold_42.text())
                        
                        ic_threshold_43 = float(self.inputInt_threshold_43.text())

                        ic_threshold_44 = float(self.inputInt_threshold_44.text())
                                                                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_4,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)
                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)                        
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)                        

            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2, hyd3, hyd4)
            perc_rech_area_1, perc_rech_area_2, perc_rech_area_3, perc_rech_area_4 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2, hyd3, hyd4)
            
            input_parameters = [rech_area, float(self.E_b_ini_4.text()), float(self.k_b_4.text()), perc_rech_area_1, 
                                float(self.l_41.text()), float(self.k_e_41.text()), float(self.E_ini_41.text()), 
                                float(self.e_min_41.text()), float(self.e_max_41.text()), float(self.alpha_41.text()), 
                                float(self.k_is_41.text()), float(self.k_sec_41.text()), float(self.e_sec_41.text()),
                                perc_rech_area_2, float(self.l_42.text()), float(self.k_e_42.text()), float(self.E_ini_42.text()), 
                                float(self.e_min_42.text()), float(self.e_max_42.text()), float(self.alpha_42.text()), 
                                float(self.k_is_42.text()), float(self.k_sec_42.text()), float(self.e_sec_42.text()),
                                perc_rech_area_3, float(self.l_43.text()), float(self.k_e_43.text()), float(self.E_ini_43.text()), 
                                float(self.e_min_43.text()), float(self.e_max_43.text()), float(self.alpha_43.text()), 
                                float(self.k_is_43.text()), float(self.k_sec_43.text()), float(self.e_sec_43.text()),
                                perc_rech_area_4, float(self.l_44.text()), float(self.k_e_44.text()), float(self.E_ini_44.text()), 
                                float(self.e_min_44.text()), float(self.e_max_44.text()), float(self.alpha_44.text()), 
                                float(self.k_is_44.text()), float(self.k_sec_44.text()), float(self.e_sec_44.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2, sns_term_3, sns_term_4)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    
        q_sim_str = ser.to_string()
        name = QFileDialog.getSaveFileName(self, 'Save File')
        file = open(name,'w')
        file.write(q_sim_str)
        file.close()
 #       self.res = pd.Series(q_sim, frame.index)
#        f = fd.asksaveasfile(mode="w")   
#        f.write(ser)
#        f.close()

    def clear_layout(self, layout):
        if layout is not None:
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
                else:
                    self.clear_layout(item.layout())                

#    - Load sensors
            
    def load_sensor_list(self):
        """
            Add sensor names to ComboBoxes
        """
        query = "SELECT * FROM freewat_sensors"
        res = self.db.execute_query(query)

        self.db.close()

        self.selectPrecip.clear()
        self.selectTemp.clear()
        self.selectDischarge.clear()

        for elem in res:
            self.selectPrecip.addItem(elem[1])
            self.selectTemp.addItem(elem[1])
            self.selectDischarge.addItem(elem[1])
            
            
    
    def get_sensor_from_db(self, name):
        """
            read sensor and sensor data from db
        """
        config.db_path = self.db.get_db_path()
        
        oat = sensor.Sensor.from_sqlite(config.db_path, name)

        oat.ts_from_sqlite(config.db_path)

        return oat
    

#    - Nr. Hydrotopes -> stackedWidget_shps & stackedWidget_param


    def setnr_hydrot(self):
        """
            set all depending widgets' pages to number of hydrotopes
        """
        # restrict nr to 4
        
        nrHydrotopes = self.setNrHydrotopes.value()
        
        if nrHydrotopes == 1:
            self.stackedWidget_shps.setCurrentIndex(0)
            self.stackedWidget_param.setCurrentIndex(0)
            self.snow_model_params.setCurrentIndex(0)
            self.interception_threshold.setCurrentIndex(0)                        
            
        elif nrHydrotopes == 2:
            self.stackedWidget_shps.setCurrentIndex(1)
            self.stackedWidget_param.setCurrentIndex(1)
            self.snow_model_params.setCurrentIndex(1)
            self.interception_threshold.setCurrentIndex(1)    
            
        elif nrHydrotopes == 3:
            self.stackedWidget_shps.setCurrentIndex(2)
            self.stackedWidget_param.setCurrentIndex(2)
            self.snow_model_params.setCurrentIndex(2)
            self.interception_threshold.setCurrentIndex(2)    
            
        elif nrHydrotopes == 4:
            self.stackedWidget_shps.setCurrentIndex(3)
            self.stackedWidget_param.setCurrentIndex(3)    
            self.snow_model_params.setCurrentIndex(3)
            self.interception_threshold.setCurrentIndex(3)            


#    - Input Hydrotope shps --> shpManager

#    - Snow model, Interception , Evapotranspiration
            
    def toggle_button_snow(self, button):
        """
            toggle event listener to input data GroupBox
        Args:
            button (QRadioButton): pressed radio button
        """
       
        if button.isChecked() == True:
            self.model_parts_snow_model.setEnabled(False)
        else:
            self.model_parts_snow_model.setEnabled(True)
        
        

    def toggle_button_intercep(self, button):
        """
            toggle event listener to input data GroupBox
        Args:
            button (QRadioButton): pressed radio button
        """
    
        if button.isChecked() == True:
            self.model_parts_interception.setEnabled(False)
        else:
            self.model_parts_interception.setEnabled(True)

        
    def __set_selected_snow(self, pressed):
        """
            Enable params input to snow model
        """

      #  snow_on = self.setSnowModelOn.text()
#        snow_off = self.setSnowModelOff.text()
      #  if pressed == snow_on:
      #      self.model_parts_snow_model.setEnabled(True)
#        elif pressed == snow_off:
#            self.model_parts_snow_model.setEnabled(False)
      #  else:
      #      self.model_parts_snow_model.setEnabled(False)

    def __set_selected_intercep(self, pressed):
        """
            Enable params input to interception model
        """

      #  intercep_on = self.setInterceptionOn.text()
#        intercep_off = self.setInterceptionOff.text()
      #  if pressed == intercep_on:
      #      self.model_parts_interception.setEnabled(True)
#        elif pressed == intercep_off:
#            self.model_parts_interception.setEnabled(False)
      #  else:
      #      self.model_parts_interception.setEnabled(False)



#    - Warm up-, Calibration period + Validation period

    def set_date(self, widget_begin, widget_end, begin, end):
        """
            Set begin and end position to date widget
        """
        # further reading of DateTimes boxes within check_validity and run_model
        widget_begin.setDate(begin)
        widget_end.setDate(end)
        
#    - load Parameter from shapefiles         


    def load_param(self):
        """
            Get parameters from attribute tables of hydrotopes' shapefiles and load them into QLineEdits of tab Define Parameters
        """
        
        # get number of hydrtopes from GUI
        nrHydrotopes = self.setNrHydrotopes.value()
        
        # set column names for attribute table
        E_b_ini = self.textRowE_b_ini_13.text()
        k_b = self.textRowk_b_13.text()
        E_ini = self.textRowE_ini_13.text()
        l = self.textRowl_13.text()
        alpha = self.textRowalpha_13.text()
        k_e = self.textRowk_e_13.text()
        k_is = self.textRowk_is_13.text()
        k_sec = self.textRowk_sec_13.text()
        e_min = self.textRowe_min_13.text()
        e_max = self.textRowe_max_13.text()
        e_sec= self.textRowe_sec_13.text()
        
        # create list with column names for attribute table
        ls_def_par = [E_b_ini, k_b, E_ini, l, alpha, k_e, k_is, k_sec, e_min, 
                      e_max, e_sec]
        
        
        dic = self.get_params_from_layers(nrHydrotopes, ls_def_par)
        
        self.write_params_to_lukars(dic, nrHydrotopes, ls_def_par)
     
  
    def get_params_from_layers(self, nrHydrotopes, ls_def_par):
        """
            Get parameters from attribute tables of hydrotopes' shapefiles
        """
             
        # create dictionary to return
        dic = {}
        
        if nrHydrotopes == 1:
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer11.currentText())
            
            # get first feature of vector layer 
            f_1 = hyd1.getFeatures()
            a_1 = next(f_1)
            
            # read parameters from vector layers and assign them to dictionary
            for i in ls_def_par:
                try:
                    dic[i] = [str(a_1[i])]
                except:
                    dic[i] = ['']
        
        if nrHydrotopes == 2:
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer21.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer22.currentText())
            
            # get first feature of vector layers 
            f_1 = hyd1.getFeatures()
            a_1 = next(f_1)
            f_2 = hyd2.getFeatures()
            a_2 = next(f_2)
            
            # read parameters from vector layers and assign them to dictionary
            for i in ls_def_par:
                try:
                    dic[i] = [str(a_1[i])]                   
                except:
                    dic[i] = ['']
                
                try:
                    dic[i].append(str(a_2[i]))
                except:
                    dic[i].append('')
        
        if nrHydrotopes == 3:            
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer31.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer32.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer33.currentText())
            
            # get first feature of vector layers 
            f_1 = hyd1.getFeatures()
            a_1 = next(f_1)
            f_2 = hyd2.getFeatures()
            a_2 = next(f_2)
            f_3 = hyd3.getFeatures()
            a_3 = next(f_3)
            
            # read parameters from vector layers and assign them to dictionary
            for i in ls_def_par:
                try:
                    dic[i] = [str(a_1[i])]                   
                except:
                    dic[i] = ['']
                
                try:
                    dic[i].append(str(a_2[i]))
                except:
                    dic[i].append('')
                
                try:
                    dic[i].append(str(a_3[i]))
                except:
                    dic[i].append('')
                
        if nrHydrotopes == 4:
                
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer41.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer42.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer43.currentText())
            hyd4 = ftools_utils.getMapLayerByName(self.listSourceLayer44.currentText())
        
            # get first feature of vector layers and 
            f_1 = hyd1.getFeatures()
            a_1 = next(f_1)
            f_2 = hyd2.getFeatures()
            a_2 = next(f_2)
            f_3 = hyd3.getFeatures()
            a_3 = next(f_3)
            f_4 = hyd4.getFeatures()
            a_4 = next(f_4)
            
            # read parameters from vector layers and assign them to dictionary
            for i in ls_def_par:
                try:
                    dic[i] = [str(a_1[i])]                   
                except:
                    dic[i] = ['']
                
                try:
                    dic[i].append(str(a_2[i]))
                except:
                    dic[i].append('')
                
                try:
                    dic[i].append(str(a_3[i]))
                except:
                    dic[i].append('')
                
                try:
                    dic[i].append(str(a_4[i]))
                except:
                    dic[i].append('')
                    
        return dic
    
    
    def write_params_to_lukars(self, dic, nrHydrotopes, ls_def_par):
        """
            Transfer parameters from attribute tables of hydrotopes' shapefiles to QLineEdits in tab Define Parameters
        """
        
        if nrHydrotopes == 1:
            
            # create list with QLineEdits
            ls_edits_1 = [self.E_b_ini_1, self.k_b_1, self.E_ini_11, self.l_11, 
                          self.alpha_11, self.k_e_11, self.k_is_11, self.k_sec_11, 
                          self.e_min_11, self.e_max_11, self.e_sec_11]
            
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_1[i].setText(dic[ls_def_par[i]][0])
                except:
                    pass
            
            
        if nrHydrotopes == 2:
            
            # create list with QLineEdits
            ls_edits_1 = [self.E_b_ini_2, self.k_b_2, self.E_ini_21, self.l_21, 
                          self.alpha_21, self.k_e_21, self.k_is_21, self.k_sec_21, 
                          self.e_min_21, self.e_max_21, self.e_sec_21]
            
            ls_edits_2 = [self.E_ini_22, self.l_22, self.alpha_22, self.k_e_22, 
                          self.k_is_22, self.k_sec_22, self.e_min_22, self.e_max_22, 
                          self.e_sec_22]           
            
            # write attributes of hydrotope 1 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_1[i].setText(dic[ls_def_par[i]][0])
                except:
                    pass
            
            del ls_def_par[0:2]
            
            # write attributes of hydrotope 2 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_2[i].setText(dic[ls_def_par[i]][1])
                except:
                    pass
        
        if nrHydrotopes == 3:
            
             # create list with QLineEdits
            ls_edits_1 = [self.E_b_ini_3, self.k_b_3, self.E_ini_31, self.l_31, 
                          self.alpha_31, self.k_e_31, self.k_is_31, self.k_sec_31, 
                          self.e_min_31, self.e_max_31, self.e_sec_31]
            
            ls_edits_2 = [self.E_ini_32, self.l_32, self.alpha_32, self.k_e_32, 
                          self.k_is_32, self.k_sec_32, self.e_min_32, self.e_max_32, 
                          self.e_sec_32]
           
            ls_edits_3 = [self.E_ini_33, self.l_33, self.alpha_33, self.k_e_33, 
                          self.k_is_33, self.k_sec_33, self.e_min_33, self.e_max_33, 
                          self.e_sec_33]
            
            # write attributes of hydrotope 1 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_1[i].setText(dic[ls_def_par[i]][0])
                except:
                    pass
            
            del ls_def_par[0:2]
            
            # write attributes of hydrotope 2 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_2[i].setText(dic[ls_def_par[i]][1])
                except:
                    pass
            
            # write attributes of hydrotope 3 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_3[i].setText(dic[ls_def_par[i]][2])
                except:
                    pass
        
        if nrHydrotopes == 4:
            
            # create list with QLineEdits
            ls_edits_1 = [self.E_b_ini_4, self.k_b_4,self.E_ini_41, self.l_41, 
                          self.alpha_41, self.k_e_41, self.k_is_41, self.k_sec_41, 
                          self.e_min_41, self.e_max_41, self.e_sec_41]
            
            ls_edits_2 = [self.E_ini_42, self.l_42, self.alpha_42, self.k_e_42, 
                          self.k_is_42, self.k_sec_42, self.e_min_42, self.e_max_42, 
                          self.e_sec_42]
           
            ls_edits_3 = [self.E_ini_43, self.l_43, self.alpha_43, self.k_e_43, 
                          self.k_is_43, self.k_sec_43, self.e_min_43, self.e_max_43, 
                          self.e_sec_43]
           
            ls_edits_4 = [self.E_ini_44, self.l_44, self.alpha_44, self.k_e_44, 
                          self.k_is_44, self.k_sec_44, self.e_min_44, self.e_max_44, 
                          self.e_sec_44]
            
            # write attributes of hydrotope 1 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_1[i].setText(dic[ls_def_par[i]][0])
                except:
                    pass
            
            del ls_def_par[0:2]
            
            # write attributes of hydrotope 2 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_2[i].setText(dic[ls_def_par[i]][1])
                except:
                    pass
            
            # write attributes of hydrotope 3 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_3[i].setText(dic[ls_def_par[i]][2])
                except:
                    pass
            
            # write attributes of hydrotope 4 to QTextEdits 
            for i in range(len(ls_def_par)):
                try:
                    ls_edits_4[i].setText(dic[ls_def_par[i]][3])
                except:
                    pass
      
      
                        
#    - Input file parameters (csv) --> params_csvManager

    def open_csv_finder(self):
        """
            Module params_csvManager: opens csv finder in explorer
        """
        self.csv.open_csv_finder()
        
        
    def load_csv_data(self):
        """
            Loads data from csv-file and writes them to QLineEdits in tab Define Parameters
        """
        
        # get number of hydrtopes from GUI
        nrHydrotopes = self.setNrHydrotopes.value()
        
        # set column names for attribute table
        E_b_ini = self.textRowE_b_ini_1.text()
        k_b = self.textRowk_b_1.text()
        E_ini = self.textRowE_ini_13.text()
        l = self.textRowl_13.text()
        alpha = self.textRowalpha_13.text()
        k_e = self.textRowk_e_13.text()
        k_is = self.textRowk_is_13.text()
        k_sec = self.textRowk_sec_13.text()
        e_min = self.textRowe_min_13.text()
        e_max = self.textRowe_max_13.text()
        e_sec= self.textRowe_sec_13.text()
        
        # create list with column names for attribute table
        ls_def_par = [E_b_ini, k_b, E_ini, l, alpha, k_e, k_is, k_sec, e_min, 
                      e_max, e_sec]
        
        # get path of .csv file
        path = self.filePath.text()

        if path == "":
			QMessageBox.warning(self, self.tr("Warning"), self.tr('Please select path for .csv file.'))
			return None
        
        # assign selected separator
        if self.radioButton_Semicolon.isChecked() == True:
            separator = ';'
        elif self.radioButton_Tab.isChecked() == True:
            separator = "\t*"
        elif self.radioButton_Space.isChecked() == True:
            separator = "\s*"
        elif self.radioButton_Comma.isChecked() == True:
            separator = ','
        
        # return dictionary with parameters from .csv file
        dic = self.csv.load_csv_param_data(path, sep=separator)
        
        # write parameters to Lukars
        self.shp.write_params_to_lukars(dic, nrHydrotopes, ls_def_par )
        
        
        
#    - Check Validity: Check if everything correctly assigned and then enable Define Parameters tab
        
    def check_validity(self):
        """
            Check if valid input in tab 'Create model' and then enable tab 'Define parameter'
        """  
        val = 'valid'
        
        nrHydrotopes = self.setNrHydrotopes.value()
        
        if self.selectPrecip.currentText() ==  '':
            QMessageBox.warning(self, self.tr("Warning"), self.tr('No sensors available. First register sensors in OAT.'))
            val = 'invalid'
            
        # check if periods overlap and possibly adapt dates             
        warm_end = self.warmUpEnd.date()
        
        cal_begin = self.calibrateBegin.date()
        cal_end = self.calibrateEnd.date()

        val_begin = self.validateBegin.date()
        val_end = self.validateEnd.date()

        if warm_end > cal_begin: #+1 needs to be changed if time step of the 3 periods is of different size
            QMessageBox.warning(self, self.tr("Warning"), 
                                self.tr('Warm-up period overlaps with calibration period! Start of calibration period will be set to end of warm-up period.'))
            self.set_date(self.calibrateBegin, self.calibrateEnd, warm_end.addDays(1), cal_end)        
        if warm_end > val_begin:
            QMessageBox.warning(self, self.tr("Warning"), 
                                self.tr('Warm-up period overlaps with validation period! Start of validation period will be set to end of warm-up period.'))
            self.set_date(self.validateBegin, self.validateEnd, warm_end.addDays(1), val_end)
        if cal_end > val_begin:
            QMessageBox.warning(self, self.tr("Warning"), 
                                self.tr('Calibration period overlaps with validation period! Start of validation period will be set to end of calibration period.'))
            self.set_date(self.validateBegin, self.validateEnd, cal_end.addDays(1), val_end)

        # Check for valid inputs of snow and interception model
        if nrHydrotopes == 1:

            if self.setSnowModelOn.isChecked() == True:
                if self.inputMeltFactor_11.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melt factor assigned!'))
                    val = 'invalid'
                if self.inputMeltingThreshold_11.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melting threshold assigned!'))
                    val = 'invalid'
            if self.setInterceptionOn.isChecked() == True:
                if self.inputInt_threshold_11.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No interception threshold assigned!'))
                    val = 'invalid'

        if nrHydrotopes == 2:

            if self.setSnowModelOn.isChecked() == True:
                if self.inputMeltFactor_21.text() ==  '' or self.inputMeltFactor_22.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melt factor assigned for one or more hydrotopes!'))
                    return
                if self.inputMeltingThreshold_21.text() ==  '' or self.inputMeltingThreshold_22.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melting threshold assigned for one or more hydrotopes!'))
                    return
            if self.setInterceptionOn.isChecked() == True:
                if self.inputInt_threshold_21.text() ==  '' or self.inputInt_threshold_22.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No interception threshold assigned for one or more hydrotopes!'))
                    return
                    
                    
        if nrHydrotopes == 3:

            if self.setSnowModelOn.isChecked() == True:
                if self.inputMeltFactor_31.text() ==  '' or self.inputMeltFactor_32.text() ==  '' or self.inputMeltFactor_33.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('No melt factor assigned for one or more hydrotopes!'))
                    return
                if self.inputMeltingThreshold_31.text() ==  '' or self.inputMeltingThreshold_32.text() ==  '' or self.inputMeltingThreshold_33.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('No melting threshold assigned for one or more hydrotopes!'))
                    return
            if self.setInterceptionOn.isChecked() == True:
                if self.inputInt_threshold_31.text() ==  '' or self.inputInt_threshold_32.text() ==  '' or self.inputInt_threshold_33.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('No interception threshold assigned for one or more hydrotopes!'))
                    return
                   
                    
        if nrHydrotopes == 4:

            if self.setSnowModelOn.isChecked() == True:
                if self.inputMeltFactor_41.text() ==  '' or self.inputMeltFactor_42.text() ==  '' or self.inputMeltFactor_43.text() ==  '' or self.inputMeltFactor_44.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melt factor assigned for one or more hydrotopes!'))
                    return
                if self.inputMeltingThreshold_41.text() ==  '' or self.inputMeltingThreshold_42.text() ==  '' or self.inputMeltingThreshold_43.text() ==  '' or self.inputMeltingThreshold_44.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No melting threshold assigned for one or more hydrotopes!'))
                    return
            if self.setInterceptionOn.isChecked() == True:
                if self.inputInt_threshold_41.text() ==  '' or self.inputInt_threshold_42.text() ==  '' or self.inputInt_threshold_43.text() ==  '' or self.inputInt_threshold_44.text() ==  '':
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('No interception threshold assigned for one or more hydrotopes!'))
                    return
                    
        if val == 'valid':
            self.Define_parameters.setEnabled(True)                
            QMessageBox.information(self, "LuKARS", "Input valid! Parameters can now be defined.")
            


#    - plot results

    def plot_results(self):
        """
            Plots model output results
        """  
        
        # Create preview data chart
        chart = MatplotWidget(toolbar=True)
        chart.set_data(self.discharge) #discharge from sensor
        #chart.set_data(self.luksens) #computed data from model
        self.clear_layout(self.chartLayout.layout())
        self.chartLayout.layout().addWidget(chart)

        return True   
        

#    - Run model    

    def run(self):
        """
            Runs the model and plots the results
        """  
        self.plot = plot.Window(self)
        self.run_model()


    def run_model(self):
        """
            Event listener to 'Run model' button
            Load the data and plot observed vs. modelled curve
        """
        nrHydrotopes = self.setNrHydrotopes.value()
        
        precip = self.selectPrecip.currentText()
        temp = self.selectTemp.currentText()
        discharge = self.selectDischarge.currentText() 

        # load sensor data for precipitation, temperature and discharge sensor
        self.precip = self.get_sensor_from_db(precip)
        self.temp = self.get_sensor_from_db(temp)
        self.discharge = self.get_sensor_from_db(discharge)

        # create data frame and clear data
        frame = pd.concat([self.precip.ts['data'], self.temp.ts['data'], 
                           self.discharge.ts['data']], axis=1).dropna()
        
        frame.columns = ['P', 'T', 'Q']

        # get dates for warm-up period from GUI
        warm_begin = self.warmUpBegin.date().toPyDate()
        
        # get dates for calibration period from GUI
        cal_begin = self.calibrateBegin.date().toPyDate()
        cal_end = self.calibrateEnd.date().toPyDate()
        period_c = basefun.model_period(cal_begin, cal_end, 'D')
        
        # get dates for validation period from GUI
        val_begin = self.validateBegin.date().toPyDate()
        val_end = self.validateEnd.date().toPyDate()
        period_v = basefun.model_period(val_begin, val_end, 'D')
        
        
                
        # create input frame
        frame = frame.loc[warm_begin:val_end]       
        period_model = basefun.model_period(warm_begin, val_end, 'D')
        
        
        if nrHydrotopes == 1:
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer11.currentText())
                
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T'])   
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                

                elif self.setInterceptionOn.isChecked == True:
        
                    try:
                        ic_threshold_11 = float(self.inputInt_threshold_11.text())    
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) 


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = None)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = None)                
    
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_11 = float(self.inputMeltFactor_11.text())
                    temp_threshold_11 = float(self.inputMeltingThreshold_11.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt        = basefun.t_index_model(frame['T'], mf_11, temp_threshold_11)
                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T'])    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_11 = float(self.inputInt_threshold_11.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et            = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_11, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_11)                        


            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1)
            perc_rech_area_1 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1)
            
            input_parameters = [rech_area, float(self.E_b_ini_1.text()), float(self.k_b_1.text()), perc_rech_area_1, 
                                float(self.l_11.text()), float(self.k_e_11.text()), float(self.E_ini_11.text()), 
                                float(self.e_min_11.text()), float(self.e_max_11.text()), float(self.alpha_11.text()), 
                                float(self.k_is_11.text()), float(self.k_sec_11.text()), float(self.e_sec_11.text())]
                                  
            
           # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e                                

        if nrHydrotopes == 2:        
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer21.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer22.currentText())
                            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                                        
        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_21 = float(self.inputInt_threshold_21.text())
                        ic_threshold_22 = float(self.inputInt_threshold_22.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = None)
                
                    elif self.setEvapoOn.isCheked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = None)        
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_21.text())
                    
                    temp_threshold_21 = float(self.inputMeltingThreshold_21.text())

                    mf_2 = float(self.inputMeltFactor_22.text())
                    
                    temp_threshold_22 = float(self.inputMeltingThreshold_22.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_21) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_22) #t_index_model(temperature_ts, melt_factor, t_threshold)
                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_21 = float(self.inputInt_threshold_21.text())
                        
                        ic_threshold_22 = float(self.inputInt_threshold_22.text())
                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_21, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_21)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_22, 
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_22)
                        
            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2)
            perc_rech_area_1, perc_rech_area_2 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2)
            
            input_parameters = [rech_area, float(self.E_b_ini_2.text()), float(self.k_b_2.text()), perc_rech_area_1, 
                                float(self.l_21.text()), float(self.k_e_21.text()), float(self.E_ini_21.text()), 
                                float(self.e_min_21.text()), float(self.e_max_21.text()), float(self.alpha_21.text()), 
                                float(self.k_is_21.text()), float(self.k_sec_21.text()), float(self.e_sec_21.text()),
                                perc_rech_area_2, float(self.l_22.text()), float(self.k_e_22.text()), float(self.E_ini_22.text()), 
                                float(self.e_min_22.text()), float(self.e_max_22.text()), float(self.alpha_22.text()), 
                                float(self.k_is_22.text()), float(self.k_sec_22.text()), float(self.e_sec_22.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2) 
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    


        if nrHydrotopes == 3:        
            
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer31.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer32.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer33.currentText())
                            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)
                                        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = None, interception_threshold = None, 
                                        temperature_ts = frame['T'], t_threshold = None)                


                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_31 = float(self.inputInt_threshold_31.text())
                        ic_threshold_32 = float(self.inputInt_threshold_32.text())  
                        ic_threshold_33 = float(self.inputInt_threshold_33.text())
                        
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_31, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_32, 
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_33, 
                                        temperature_ts = frame['T'], t_threshold = None)
                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_31, 
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None, 
                                        interception_losses = intercep, interception_threshold = ic_threshold_32, 
                                        temperature_ts = frame['T'], t_threshold = None)        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = None)    
                                        
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_31.text())
                    
                    temp_threshold_31 = float(self.inputMeltingThreshold_31.text())

                    mf_2 = float(self.inputMeltFactor_32.text())
                    
                    temp_threshold_32 = float(self.inputMeltingThreshold_32.text())

                    mf_3 = float(self.inputMeltFactor_33.text())
                    
                    temp_threshold_33 = float(self.inputMeltingThreshold_33.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_31) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_32) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_3        = basefun.t_index_model(frame['T'], mf_3, temp_threshold_33) #t_index_model(temperature_ts, melt_factor, t_threshold)                
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1, 
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)
                            
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_31 = float(self.inputInt_threshold_31.text())
                        
                        ic_threshold_32 = float(self.inputInt_threshold_32.text())
                        
                        ic_threshold_33 = float(self.inputInt_threshold_33.text())
                                                    
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_31,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_32,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)
                        
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_31,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_31)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_32,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_32)                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_33,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_33)                        

            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2, hyd3)
            perc_rech_area_1, perc_rech_area_2, perc_rech_area_3 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2, hyd3)
            
            input_parameters = [rech_area, float(self.E_b_ini_3.text()), float(self.k_b_3.text()), perc_rech_area_1, 
                                float(self.l_31.text()), float(self.k_e_31.text()), float(self.E_ini_31.text()), 
                                float(self.e_min_31.text()), float(self.e_max_31.text()), float(self.alpha_31.text()), 
                                float(self.k_is_31.text()), float(self.k_sec_31.text()), float(self.e_sec_31.text()),
                                perc_rech_area_2, float(self.l_32.text()), float(self.k_e_32.text()), float(self.E_ini_32.text()), 
                                float(self.e_min_32.text()), float(self.e_max_32.text()), float(self.alpha_32.text()), 
                                float(self.k_is_32.text()), float(self.k_sec_32.text()), float(self.e_sec_32.text()),
                                perc_rech_area_3, float(self.l_33.text()), float(self.k_e_33.text()), float(self.E_ini_33.text()), 
                                float(self.e_min_33.text()), float(self.e_max_33.text()), float(self.alpha_33.text()), 
                                float(self.k_is_33.text()), float(self.k_sec_33.text()), float(self.e_sec_33.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2, sns_term_3)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    



        if nrHydrotopes == 4:        
                                                        
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer41.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer42.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer43.currentText())
            hyd4 = ftools_utils.getMapLayerByName(self.listSourceLayer44.currentText())
            
            if self.setSnowModelOff.isChecked() == True:
            
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)
                                                                    
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = None)                


                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_41 = float(self.inputInt_threshold_41.text())
                        ic_threshold_42 = float(self.inputInt_threshold_42.text())
                        ic_threshold_43 = float(self.inputInt_threshold_43.text()) 
                        ic_threshold_44 = float(self.inputInt_threshold_44.text())   
                                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)


                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = None)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = None)
                                                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = None)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = None)        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = None)    
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = None,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = None)    
                                                
            elif self.setSnowModelOn.isChecked() == True:
            
                try:
                    mf_1 = float(self.inputMeltFactor_41.text())
                    
                    temp_threshold_41 = float(self.inputMeltingThreshold_41.text())

                    mf_2 = float(self.inputMeltFactor_42.text())
                    
                    temp_threshold_42 = float(self.inputMeltingThreshold_42.text())

                    mf_3 = float(self.inputMeltFactor_43.text())
                    
                    temp_threshold_43 = float(self.inputMeltingThreshold_43.text())
                    
                    mf_4 = float(self.inputMeltFactor_44.text())
                    
                    temp_threshold_44 = float(self.inputMeltingThreshold_44.text())
                    
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of melt factor/temp threshold failed.'))
                    print e    

                melt_1        = basefun.t_index_model(frame['T'], mf_1, temp_threshold_41) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_2        = basefun.t_index_model(frame['T'], mf_2, temp_threshold_42) #t_index_model(temperature_ts, melt_factor, t_threshold)
                melt_3        = basefun.t_index_model(frame['T'], mf_3, temp_threshold_43) #t_index_model(temperature_ts, melt_factor, t_threshold)                
                melt_4        = basefun.t_index_model(frame['T'], mf_4, temp_threshold_43) #t_index_model(temperature_ts, melt_factor, t_threshold)                
                    
                if self.setInterceptionOff.isChecked() == True:
                
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_4,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)
                                            
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)                
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)                
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)                
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_4,
                                        interception_losses = None, interception_threshold = None,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)                

                elif self.setInterceptionOn.isChecked() == True:
        
                    try:
                        ic_threshold_41 = float(self.inputInt_threshold_41.text())
                        
                        ic_threshold_42 = float(self.inputInt_threshold_42.text())
                        
                        ic_threshold_43 = float(self.inputInt_threshold_43.text())

                        ic_threshold_44 = float(self.inputInt_threshold_44.text())
                                                                                
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Warning"), self.tr('Reading of interception threshold failed.'))
                        print e    

                    intercep    = basefun.interception_losses(period_model) #interception_losses(model_period)
                    
                    if self.setEvapoOff.isChecked() == True:
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = None, snow_model = melt_4,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)
                                
                    elif self.setEvapoOn.isChecked() == True:        
                        et          = basefun.et_model(period_model, frame['T']) #et_model(model_period, temperature_ts)    
                        sns_term_1    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_1,
                                        interception_losses = intercep, interception_threshold = ic_threshold_41,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_41)                        
                        sns_term_2    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_2,
                                        interception_losses = intercep, interception_threshold = ic_threshold_42,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_42)                        
                        sns_term_3    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_43,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_43)                        
                        sns_term_4    = basefun.sink_n_source(frame['P'], et_model = et, snow_model = melt_3,
                                        interception_losses = intercep, interception_threshold = ic_threshold_44,
                                        temperature_ts = frame['T'], t_threshold = temp_threshold_44)                        

            rech_area = self.shp.calculate_recharge_area(nrHydrotopes, hyd1, hyd2, hyd3, hyd4)
            perc_rech_area_1, perc_rech_area_2, perc_rech_area_3, perc_rech_area_4 = self.shp.calculate_perc_rech_area(nrHydrotopes, rech_area, hyd1, hyd2, hyd3, hyd4)
            
            input_parameters = [rech_area, float(self.E_b_ini_4.text()), float(self.k_b_4.text()), perc_rech_area_1, 
                                float(self.l_41.text()), float(self.k_e_41.text()), float(self.E_ini_41.text()), 
                                float(self.e_min_41.text()), float(self.e_max_41.text()), float(self.alpha_41.text()), 
                                float(self.k_is_41.text()), float(self.k_sec_41.text()), float(self.e_sec_41.text()),
                                perc_rech_area_2, float(self.l_42.text()), float(self.k_e_42.text()), float(self.E_ini_42.text()), 
                                float(self.e_min_42.text()), float(self.e_max_42.text()), float(self.alpha_42.text()), 
                                float(self.k_is_42.text()), float(self.k_sec_42.text()), float(self.e_sec_42.text()),
                                perc_rech_area_3, float(self.l_43.text()), float(self.k_e_43.text()), float(self.E_ini_43.text()), 
                                float(self.e_min_43.text()), float(self.e_max_43.text()), float(self.alpha_43.text()), 
                                float(self.k_is_43.text()), float(self.k_sec_43.text()), float(self.e_sec_43.text()),
                                perc_rech_area_4, float(self.l_44.text()), float(self.k_e_44.text()), float(self.E_ini_44.text()), 
                                float(self.e_min_44.text()), float(self.e_max_44.text()), float(self.alpha_44.text()), 
                                float(self.k_is_44.text()), float(self.k_sec_44.text()), float(self.e_sec_44.text())]
            
            # try:
            q_sim = basefun.lukars(input_parameters, nrHydrotopes, sns_term_1, sns_term_2, sns_term_3, sns_term_4)
            ser = pd.Series(q_sim, frame.index)
           # except Exception as e:
           #     QMessageBox.warning(self, self.tr("Warning"), self.tr('Running model with 1 hydrotope failed.'))
           #     print e    
        
 #       self.res = pd.Series(q_sim, frame.index)
        self.plot.plot(frame['Q'], ser, period_c, period_v)
        self.plot.show()


#    - Take parameters on to hydrotope shapefiles' attribute table

        
    def save_param(self):
        """
            Load parameters into attribute table of hydrotopes' shapefiles
        """
        self.saveparam()
        
#        if freewat.ftools_utils.getMapLayerByName(unicode(self.listSourceLayer11.currentText())) == None and 
#        if freewat.ftools_utils.getMapLayerByName(unicode(self.listSourceLayer21.currentText())) == None and 
#        if freewat.ftools_utils.getMapLayerByName(unicode(self.listSourceLayer31.currentText())) == None and 
#        if freewat.ftools_utils.getMapLayerByName(unicode(self.listSourceLayer41.currentText())) == None: 
#            QMessageBox.warning(self, self.tr("Warning"), self.tr('No hydrotope shapefile assigned!'))

#        else:
#            self.shp.save_param_data()
        
        self.shp.save_param_data()
        

    def take_on(self):
        
        # get number of hydrtopes from GUI
        nrHydrotopes = self.setNrHydrotopes.value()
        
        # set column names for attribute table
        area = u'area'
        E_b_ini = self.textRowE_b_ini_13.text()
        k_b = self.textRowk_b_13.text()
        E_ini = self.textRowE_ini_13.text()
        l = self.textRowl_13.text()
        alpha = self.textRowalpha_13.text()
        k_e = self.textRowk_e_13.text()
        k_is = self.textRowk_is_13.text()
        k_sec = self.textRowk_sec_13.text()
        e_min = self.textRowe_min_13.text()
        e_max = self.textRowe_max_13.text()
        e_sec= self.textRowe_sec_13.text()
        
        # create list with column names for attribute table
        ls_def_par = [area, E_b_ini, k_b, E_ini, l, alpha, k_e, k_is, k_sec, e_min, 
                      e_max, e_sec] 
        
        if nrHydrotopes == 1:
            
            # get vector layer
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer11.currentText())
            pr1 = hyd1.dataProvider()
             
            fields1 = hyd1.pendingFields()
            attr_cols_hyd1 = [col.name() for col in fields1]
            
            # check if attribute columns already exist and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd1:                                           
                    pr1.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd1.updateFields()
            
            ls_def_par.remove(area)
            
            # Check if parameters are loaded via CSV 
            if self.setFileType_CSV.isChecked() == True:
                pass
            else:
                # Create dictionary with assigned values from define parameters
                try:
                    dic_hyd1 = {
                        E_b_ini: float(self.E_b_ini_1.text()),
                        k_b: float(self.k_b_1.text()),
                        E_ini: float(self.E_ini_11.text()),
                        l : float(self.l_11.text()),
                        alpha: float(self.alpha_11.text()),
                        k_e: float(self.k_e_11.text()),
                        k_is: float(self.k_is_11.text()),
                        k_sec: float(self.k_sec_11.text()),
                        e_min: float(self.e_min_11.text()),
                        e_max: float(self.e_max_11.text()),
                        e_sec: float(self.e_sec_11.text())                        
                        }                    
                except:
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('One or more inputs are missing!'))
                    return
                
                # Write inputs to attribute table
                hyd1.startEditing()               
                for f in hyd1.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd1[k]
                        
                    hyd1.updateFeature(f)
                
                hyd1.commitChanges()
        
        if nrHydrotopes == 2:
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer21.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer22.currentText())
            pr1 = hyd1.dataProvider()
            pr2 = hyd2.dataProvider()
             
            fields1 = hyd1.pendingFields()
            fields2 = hyd2.pendingFields()
            attr_cols_hyd1 = [col.name() for col in fields1]
            attr_cols_hyd2 = [col.name() for col in fields2]
            
            # check if attribute columns already exist for hydrotope 1 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd1:                                           
                    pr1.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd1.updateFields()
            
            # check if attribute columns already exist for hydrotope 2 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd2:                                           
                    pr2.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd2.updateFields()
            
            ls_def_par.remove(area)
            
            # Check if parameters are loaded via CSV 
            if self.setFileType_CSV.isChecked() == True:
                pass
            else:
                # Create dictionary with assigned values from define parameters
                try:
                    dic_hyd2 = {
                        E_b_ini: [float(self.E_b_ini_2.text()), float(self.E_b_ini_2.text())],
                        k_b: [float(self.k_b_2.text()), float(self.k_b_2.text())],
                        E_ini: [float(self.E_ini_21.text()), float(self.E_ini_22.text())],
                        l : [float(self.l_21.text()), float(self.l_22.text())],
                        alpha: [float(self.alpha_21.text()), float(self.alpha_22.text())],
                        k_e: [float(self.k_e_21.text()), float(self.k_e_22.text())],
                        k_is: [float(self.k_is_21.text()), float(self.k_is_22.text())],
                        k_sec: [float(self.k_sec_21.text()), float(self.k_sec_22.text())],
                        e_min: [float(self.e_min_21.text()), float(self.e_min_22.text())],
                        e_max: [float(self.e_max_21.text()), float(self.e_max_22.text())],
                        e_sec: [float(self.e_sec_21.text()), float(self.e_sec_22.text())]                        
                        }
                except:
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('One or more inputs are missing!'))
                    return
                
                # Write inputs to attribute table
                
                
                
                # Write to hydrotope 1
                hyd1.startEditing()
                for f in hyd1.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd2[k][0]
                        
                    hyd1.updateFeature(f)
                
                hyd1.commitChanges()
                
                # Write to hydrotope 2
                hyd2.startEditing()
                for f in hyd2.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd2[k][1]
                        
                    hyd2.updateFeature(f)
              
                hyd2.commitChanges()
        
        if nrHydrotopes == 3:
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer31.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer32.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer33.currentText())
            pr1 = hyd1.dataProvider()
            pr2 = hyd2.dataProvider()
            pr3 = hyd3.dataProvider()
             
            fields1 = hyd1.pendingFields()
            fields2 = hyd2.pendingFields()
            fields3 = hyd3.pendingFields()
            attr_cols_hyd1 = [col.name() for col in fields1]
            attr_cols_hyd2 = [col.name() for col in fields2]
            attr_cols_hyd3 = [col.name() for col in fields3]
            
            # check if attribute columns already exist for hydrotope 1 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd1:                                           
                    pr1.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd1.updateFields()
            
            # check if attribute columns already exist for hydrotope 2 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd2:                                           
                    pr2.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd2.updateFields()
            
            # check if attribute columns already exist for hydrotope 3 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd3:                                           
                    pr3.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd3.updateFields()
            
            ls_def_par.remove(area)
                
            # Check if parameters are loaded via CSV 
            if self.setFileType_CSV.isChecked() == True:
                pass
            else:
                # Create dictionary with assigned values from define parameters
                try:
                    dic_hyd3 = {
                        E_b_ini: [float(self.E_b_ini_3.text()), float(self.E_b_ini_3.text()),
                                  float(self.E_b_ini_3.text())],
                        k_b: [float(self.k_b_3.text()), float(self.k_b_3.text()),
                              float(self.k_b_3.text())],
                        E_ini: [float(self.E_ini_31.text()), float(self.E_ini_32.text()),
                                float(self.E_ini_33.text())],
                        l : [float(self.l_31.text()), float(self.l_32.text()),
                             float(self.l_33.text())],
                        alpha: [float(self.alpha_31.text()), float(self.alpha_32.text()),
                                float(self.alpha_33.text())],
                        k_e: [float(self.k_e_31.text()), float(self.k_e_32.text()),
                              float(self.k_e_33.text())],
                        k_is: [float(self.k_is_31.text()), float(self.k_is_32.text()),
                               float(self.k_is_33.text())],
                        k_sec: [float(self.k_sec_31.text()), float(self.k_sec_32.text()),
                                float(self.k_sec_33.text())],
                        e_min: [float(self.e_min_31.text()), float(self.e_min_32.text()),
                                float(self.e_min_33.text())],
                        e_max: [float(self.e_max_31.text()), float(self.e_max_32.text()),
                                float(self.e_max_33.text())],
                        e_sec: [float(self.e_sec_31.text()), float(self.e_sec_32.text()),
                                float(self.e_sec_33.text())]                        
                        }                    
                except:
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('One or more inputs are missing!'))
                    return
                
                # Write inputs to attribute table               
                # Write to hydrotope 1
                hyd1.startEditing()
                for f in hyd1.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd3[k][0]
                        
                    hyd1.updateFeature(f)
                
                hyd1.commitChanges()
                
                # Write to hydrotope 2
                hyd2.startEditing()
                for f in hyd2.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd3[k][1]
                        
                    hyd2.updateFeature(f)
                
                hyd2.commitChanges()
                
                # Write to hydrotope 3
                hyd3.startEditing()
                for f in hyd3.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd3[k][2]
                        
                    hyd3.updateFeature(f)
                
                hyd3.commitChanges()
                
        if nrHydrotopes == 4:
            
            # get vector layers
            hyd1 = ftools_utils.getMapLayerByName(self.listSourceLayer41.currentText())
            hyd2 = ftools_utils.getMapLayerByName(self.listSourceLayer42.currentText())
            hyd3 = ftools_utils.getMapLayerByName(self.listSourceLayer43.currentText())
            hyd4 = ftools_utils.getMapLayerByName(self.listSourceLayer44.currentText())
            pr1 = hyd1.dataProvider()
            pr2 = hyd2.dataProvider()
            pr3 = hyd3.dataProvider()
            pr4 = hyd4.dataProvider()
             
            fields1 = hyd1.pendingFields()
            fields2 = hyd2.pendingFields()
            fields3 = hyd3.pendingFields()
            fields4 = hyd4.pendingFields()
            attr_cols_hyd1 = [col.name() for col in fields1]
            attr_cols_hyd2 = [col.name() for col in fields2]
            attr_cols_hyd3 = [col.name() for col in fields3]
            attr_cols_hyd4 = [col.name() for col in fields4]
            
            # check if attribute columns already exist for hydrotope 1 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd1:                                           
                    pr1.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd1.updateFields()
            
            # check if attribute columns already exist for hydrotope 2 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd2:                                           
                    pr2.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd2.updateFields()
            
            # check if attribute columns already exist for hydrotope 3 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd3:                                           
                    pr3.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd3.updateFields()
            
            # check if attribute columns already exist for hydrotope 4 and if not add them
            for i in ls_def_par:
                if i not in attr_cols_hyd4:                                           
                    pr4.addAttributes([QgsField(i, QVariant.Double, 'double', 10, 5)])
    
            hyd4.updateFields()
            
            ls_def_par.remove(area)
            
            # Check if parameters are loaded via CSV 
            if self.setFileType_CSV.isChecked() == True:
                pass
            else:
                # Create dictionary with assigned values from define parameters
                try:                
                    dic_hyd4 = {
                        E_b_ini: [float(self.E_b_ini_4.text()), float(self.E_b_ini_4.text()),
                                  float(self.E_b_ini_4.text()), float(self.E_b_ini_4.text())],
                        k_b: [float(self.k_b_4.text()), float(self.k_b_4.text()),
                              float(self.k_b_4.text()), float(self.k_b_4.text())],
                        E_ini: [float(self.E_ini_41.text()), float(self.E_ini_42.text()),
                                float(self.E_ini_43.text()), float(self.E_ini_44.text())],
                        l : [float(self.l_41.text()), float(self.l_42.text()),
                             float(self.l_43.text()), float(self.l_44.text())],
                        alpha: [float(self.alpha_41.text()), float(self.alpha_42.text()),
                                float(self.alpha_43.text()), float(self.alpha_44.text())],
                        k_e: [float(self.k_e_41.text()), float(self.k_e_42.text()),
                              float(self.k_e_43.text()), float(self.k_e_44.text())],
                        k_is: [float(self.k_is_41.text()), float(self.k_is_42.text()),
                               float(self.k_is_43.text()), float(self.k_is_44.text())],
                        k_sec: [float(self.k_sec_41.text()), float(self.k_sec_42.text()),
                                float(self.k_sec_43.text()), float(self.k_sec_44.text())],
                        e_min: [float(self.e_min_41.text()), float(self.e_min_42.text()),
                                float(self.e_min_43.text()), float(self.e_min_44.text())],
                        e_max: [float(self.e_max_41.text()), float(self.e_max_42.text()),
                                float(self.e_max_43.text()), float(self.e_max_44.text())],
                        e_sec: [float(self.e_sec_41.text()), float(self.e_sec_42.text()),
                                float(self.e_sec_43.text()), float(self.e_sec_44.text())]                        
                        }
                except:
                    QMessageBox.warning(self, self.tr("Warning"), 
                                        self.tr('One or more inputs are missing!'))
                    return
                
                # Write inputs to attribute table               
                # Write to hydrotope 1
                hyd1.startEditing()
                for f in hyd1.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd4[k][0]
                        
                    hyd1.updateFeature(f)
                
                hyd1.commitChanges()
                
                # Write to hydrotope 2
                hyd2.startEditing()
                for f in hyd2.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd4[k][1]
                        
                    hyd2.updateFeature(f)
                    
                hyd2.commitChanges()
                
                # Write to hydrotope 3
                hyd3.startEditing()
                for f in hyd3.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd4[k][2]
                        
                    hyd3.updateFeature(f)
                
                hyd3.commitChanges()
                
                # Write to hydrotope 4
                hyd4.startEditing()
                for f in hyd4.getFeatures():
                    geom = f.geometry()
                    f[u'area'] = ftools_utils.getAreaAndPerimeter(geom)
                    for k in ls_def_par:
                        f[k] = dic_hyd4[k][3]
                        
                    hyd4.updateFeature(f)
                              
                hyd4.commitChanges()
            
        QMessageBox.information(self, "LuKARS", 
                                "Parameters written to attribute tables.")

