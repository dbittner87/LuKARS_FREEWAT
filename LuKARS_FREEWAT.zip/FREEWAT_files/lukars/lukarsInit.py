# -*- coding: utf-8 -*-
# ==============================================================================
#
#
# Copyright (c) 2015 IST-SUPSI (www.supsi.ch/ist)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
#
# ===============================================================================

#creates a submenu within the FREEWAT menu and calls runLuKARs_dialog.py

import sys
import os
import numpy as np
import matplotlib.pyplot as plt

# add oat module to PYTHONPATH
sys.path.append(os.path.dirname(__file__))

from PyQt4.QtCore import QCoreApplication
from PyQt4.QtGui import QAction, QMenu

import runLuKARs_dialog as runLuk


freewat = None


def create_lukars_menu(free):
    # global to "share" to all file
    global freewat
    # pointer to freewat menu
    freewat = free
    # Create lukars submenu on FREEWAT menu
    freewat.menu.lukars = QMenu(QCoreApplication.translate("FREEWAT", "LuKARS"))
    freewat.menu.addMenu(freewat.menu.lukars)
    action_run_lukars_model = QAction("Run model", freewat.iface.mainWindow())
    action_run_lukars_model.triggered.connect(run_lukars_model)
      
    # add action to LuKARs submenu
    freewat.menu.lukars.addAction(action_run_lukars_model)



####################################
### Action listener
####################################


def run_lukars_model():
    """ Run action that opens the modelling gui"""
    lukars_model = runLuk.RunLuKARsDialog(freewat.iface)
    # show the dialog
    lukars_model.show()
    # Run the dialog event loop
    lukars_model.exec_()