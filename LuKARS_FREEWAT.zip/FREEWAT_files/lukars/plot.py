# -*- coding: utf-8 -*-

"""
LuKARs plot
"""
 
from PyQt4.QtGui import QDialog, QVBoxLayout, QLabel
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

class Window(QDialog):
    def __init__(self, gui, parent=None):
        super(Window, self).__init__()
        
        self.gui = gui
        self.label = QLabel()
        self.setWindowTitle('Lukars')
                    
                
    def plot(self, observed, simulated, period_c, period_v):
        
        # edit plot parameters
        plt.rcParams['xtick.labelsize'] = 10
        plt.rcParams['ytick.labelsize'] = 10
        plt.rcParams['axes.labelsize'] = 13
        
        fig, ax = plt.subplots()
        
        ax.clear()
        
        # set up Window
        canvas = FigureCanvas(fig)
        toolbar = NavigationToolbar(canvas, self)        
        layout = QVBoxLayout()
        layout.addWidget(toolbar)
        layout.addWidget(canvas)
        layout.addWidget(self.label)
        self.setLayout(layout)
        
        # organise data
        frame = pd.concat([observed, simulated], axis=1).dropna()
        frame.columns = ['Observed', 'Simulated']
        
        cal_obs = np.array(frame.loc[period_c]['Observed'])
        cal_sim = np.array(frame.loc[period_c]['Simulated'])
        val_obs = np.array(frame.loc[period_v]['Observed'])
        val_sim = np.array(frame.loc[period_v]['Simulated'])       
        
        # calculate coefficient of determination (R^2)
        mae_cal = np.mean(np.abs(cal_obs - cal_sim))
        mae_val = np.mean(np.abs(val_obs - val_sim))
        
        # calculate Nash Sutcliffe efficiency  
        NSE_cal = 1 - np.var(cal_sim - cal_obs)/np.var(cal_obs)
        NSE_val = 1 - np.var(val_sim - val_obs)/np.var(val_obs)
        
        # write Qlabel to window
        self.label.setText("Calibration period: MAE = %.2f, NSE = %.2f\n"
                           "Validation period: MAE = %.2f, NSE = %.2f" 
                           % (mae_cal, NSE_cal, mae_val, NSE_val))
        
        # plot time series        
        ax.plot(frame['Observed'], label='Observed')
        ax.plot(frame['Simulated'], label='Simulated')
        
        # indicate calibration and validation periods with colouring
        ax.axvspan(period_c[0], period_c[-1], facecolor='green', alpha=0.3, 
                   label='Calibration period')
        ax.axvspan(period_v[0], period_v[-1], facecolor='red', alpha=0.3, 
                   label='Validation period')
        
        # adapt plot
        ax.set_xlabel('Date')
        ax.set_ylabel('Discharge')
        ax.set_xlim(period_c[0], period_v[-1])
        
        ax.legend(loc='best', fontsize=13)
        
        fig.autofmt_xdate()
        
        canvas.draw()
